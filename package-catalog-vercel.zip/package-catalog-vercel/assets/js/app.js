/* ============================================================
   Package Catalog — behaviour
   Loaded as an external file because the Content-Security-Policy
   is script-src 'self' with no 'unsafe-inline'. Inline onclick /
   onsubmit attributes are blocked by that policy, so every
   interaction here is bound from data-* attributes instead.
   Everything degrades safely: with JS off, forms still submit and
   the manual filter buttons stay visible.
   ============================================================ */
(function () {
  'use strict';

  // --- destructive actions ask first -------------------------------------
  // On the form: <form data-confirm="Delete this?">
  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    if (!(form instanceof HTMLFormElement)) return;

    var message = form.getAttribute('data-confirm');
    if (message && !window.confirm(message)) {
      ev.preventDefault();
    }
  });

  // On a single button inside a shared form, e.g. the delete button in the
  // features table that overrides the action with formaction.
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest ? ev.target.closest('[data-confirm]') : null;
    if (!el || el.tagName !== 'BUTTON') return;   // forms are handled above

    if (!window.confirm(el.getAttribute('data-confirm'))) {
      ev.preventDefault();
      ev.stopPropagation();
    }
  });

  // --- filter dropdowns submit on change ---------------------------------
  var selects = document.querySelectorAll('select[data-autosubmit]');
  Array.prototype.forEach.call(selects, function (select) {
    select.addEventListener('change', function () {
      if (select.form) select.form.submit();
    });
  });

  // The manual "go" button next to each filter exists for people without
  // JavaScript. Now that the dropdown submits itself, hide it.
  var fallbacks = document.querySelectorAll('[data-js-hide]');
  Array.prototype.forEach.call(fallbacks, function (el) {
    el.hidden = true;
  });
})();
