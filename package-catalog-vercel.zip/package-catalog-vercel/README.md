# Package Catalog — Vercel edition

A bilingual (English / አማርኛ) service-package catalogue with an admin panel.
Plain PHP 8.5 on Vercel Functions, with Vercel Postgres. No second hosting
provider, no cPanel, no server to maintain.

---

## Deploy in eight steps

### 1. Push this folder to GitHub

```bash
git init
git add .
git commit -m "Package catalog"
git remote add origin https://github.com/YOURNAME/package-catalog.git
git push -u origin main
```

### 2. Import it on Vercel

vercel.com → **Add New → Project** → pick the repository → **Deploy**.

Leave every build setting alone. `vercel.json` already tells Vercel to run
`api/index.php` on the PHP runtime and to serve `/assets/*` from the CDN.

The first deploy will fail to load data. That is expected — there is no
database yet.

### 3. Attach a Postgres database

Project → **Storage** → **Create Database** → **Postgres** → Connect.

This sets `POSTGRES_URL` automatically. You do not copy any password
anywhere; the app reads that variable at runtime.

### 4. Create the tables

Storage → your database → **Query**, then paste and run, in this order:

1. the whole of `api/database/schema.sql`
2. the whole of `api/database/seed.sql`

The seed gives you four categories, twelve packages, thirty-six features and
five add-ons, all bilingual. **Every price in it is a guess — change them in
the admin panel before you send anyone the link.**

Want to start empty? Run only `schema.sql`.

### 5. Set three environment variables

Project → Settings → **Environment Variables**:

| Name | Value | Why |
|---|---|---|
| `ADMIN_PATH` | something only you know, e.g. `sp-office` | your admin lives at `/sp-office`; stops bots finding the login form |
| `SETUP_TOKEN` | a long random string | unlocks account creation once |
| `APP_URL` | `https://your-domain.com` | optional; set it once you add a custom domain |

Generate a token with `openssl rand -hex 24`.

### 6. Redeploy

Deployments → the latest one → **Redeploy**. Environment variables only
reach the function on a fresh deploy.

### 7. Create your account

Visit `https://your-project.vercel.app/setup?token=YOUR_SETUP_TOKEN`

Minimum password length is twelve characters.

### 8. Close the door

Delete the `SETUP_TOKEN` variable and redeploy. `/setup` then returns 404
permanently. The page also refuses to run once a user exists, so this is the
second lock rather than the only one.

Sign in at `https://your-project.vercel.app/sp-office`.

---

## What changed from a normal PHP host

Vercel is serverless. Three things had to be built differently, and one
feature had to go:

**Sessions live in Postgres.** Each request may land on a different
container with its own empty `/tmp`, so PHP's default file sessions would
log you out at random and make CSRF checks reject valid forms. `sessions`
is a real table, swept automatically by PHP's garbage collector — no cron
job, which matters because Vercel has no always-on process.

**All code lives under `api/`.** Vercel serves the repository root as static
files, so `app/config.php` sitting at the root would be downloadable — your
database password in a browser. Anything inside `api/` is bundled into the
function and never served. Only `assets/` is public. This is the single most
important thing to preserve if you restructure: **never move PHP files out of
`api/`.**

**Image uploads were removed.** The filesystem is read-only apart from
`/tmp`, which is wiped between invocations, so an upload would appear to
succeed and then vanish. The category cover-image field is gone rather than
left as a feature that silently fails. Nothing on the public site used it.
If you want images later, the honest options are Vercel Blob storage or
pasting external image URLs.

**Errors go to stderr.** There is no writable log file. Read them under
Deployments → your deployment → **Runtime Logs**.

---

## How the comparison table works

This is the part worth understanding, because it is what makes the site sell.

A **feature** belongs to a *category*, not to a package. All packages in
"Real Estate" share one feature list, which is why their rows line up.

1. **Features** → pick the category → add or rename rows
2. **Packages** → edit a package → tick what it includes

In the matrix:

- **Tick only** → green ✓
- **Tick + a value** → the text instead, e.g. "Up to 20"
- **Value, no tick** → greyed text, e.g. "English only"
- **Neither** → a dash

Add the feature row first, then tick it on each package.

---

## Frozen quotes

When someone submits the form, the package is frozen into that enquiry —
name, price, delivery time, every feature, exactly as shown at that moment.

Raise a price six months later and the old enquiry still shows what that
client was actually quoted. Open any lead to read the original figures. This
is what lets you hold a price in a negotiation.

Statuses: New → Contacted → Quoted → Won / Lost. The dashboard totals Won.

---

## Security

Built in:

- Every query parameterised, emulated prepares off
- All output escaped
- CSRF tokens verified with `hash_equals`
- Passwords bcrypt-hashed, rehashed when PHP's default cost changes
- Session id regenerated on login; 30-minute idle timeout
- Login: 5 attempts per 15 minutes per IP
- Enquiries: 5 per hour per IP, plus a honeypot field and a minimum fill
  time; bots get a fake success page so they learn nothing
- Identical error for a wrong email and a wrong password
- CSP with no inline scripts or styles — all behaviour is in
  `assets/js/app.js`, bound from `data-` attributes
- Feature ids checked against their category on save, so a tampered form
  cannot attach a feature from another category
- `/setup` gated by a token compared with `hash_equals`, and disabled once a
  user exists

Yours to do:

- Delete `SETUP_TOKEN` after step 7
- Keep `APP_DEBUG` unset (or `0`)
- Back up before big edits: Storage → Query → `pg_dump`, or export from the
  Vercel dashboard

---

## Costs and limits — read before you rely on this

**Check Vercel's plan terms yourself.** The Hobby tier is intended for
non-commercial personal projects, and a site whose job is selling your
services may not qualify. If it needs Pro, that is roughly $20/month, which
changes the economics against ordinary shared hosting. Verify on Vercel's
current pricing page before you point a client at this.

Vercel Postgres free tiers have storage and compute ceilings, and databases
may pause when idle — the first request after a pause is slow. Fine for a
catalogue, worth knowing before you are surprised by it.

---

## File layout

```
vercel.json            runtime + routing
assets/                the ONLY publicly served folder
  css/style.css
  js/app.js
api/                   never served as files — bundled into the function
  index.php            front controller
  app/
    config.php         reads environment variables; no secrets in the repo
    db.php             Postgres PDO, RETURNING-based inserts
    session.php        database session handler
    security.php       headers, CSRF, rate limits
    helpers.php        escaping, translation, URLs
    validate.php  auth.php  queries.php  admin.php  setup.php
  views/               page templates
  lang/en.php  lang/am.php
  database/
    schema.sql         run first
    seed.sql           run second
```

---

## Local preview

```bash
export POSTGRES_URL="postgres://user:pass@127.0.0.1:5432/pkgcat?sslmode=disable"
export APP_URL="http://127.0.0.1:8000"
export ADMIN_PATH="sp-office"
export SETUP_TOKEN="local-token"
php -S 127.0.0.1:8000 -t . router.php
```

`router.php` mimics Vercel's routing: `/assets/*` static, everything else to
`api/index.php`. It is a development convenience and is not used in
production.

---

## Troubleshooting

**"The site is not configured yet"** — `POSTGRES_URL` is missing. Attach the
database, then redeploy.

**Logged out immediately after signing in** — the `sessions` table does not
exist. Re-run `schema.sql`.

**`/setup` returns 404** — `SETUP_TOKEN` is unset, the token in the URL does
not match, or you set the variable but did not redeploy.

**Admin path 404s** — `ADMIN_PATH` changed but you have not redeployed.

**Styles missing** — check `/assets/css/style.css` loads directly. If it
404s, the `routes` block in `vercel.json` was edited.

**Amharic shows as boxes** — a font issue on that device, not data. The
stylesheet falls back through Noto Sans Ethiopic, Nyala and Abyssinica SIL.
Confirm the data with Storage → Query → `SELECT name_am FROM categories;`

**Edits do not show up** — you changed CSS or JS but not `ASSET_VERSION` in
`api/app/config.php`. Bump it to bust the CDN cache.
