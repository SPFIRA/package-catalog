<?php
/**
 * @var array      $grouped        categories => packages, for the select
 * @var int|null   $selectedPackage
 * @var array      $errors
 */
$errors          = $errors ?? [];
$selectedPackage = $selectedPackage ?? (int) old('package_id', '0');
?>
<section class="band band--surface enquiry-band" id="enquiry">
  <div class="shell">
    <div class="band__head">
      <p class="eyebrow"><?= e(t('nav_contact')) ?></p>
      <h2 class="band__title display"><?= e(t('enquiry_heading')) ?></h2>
      <p class="band__lede"><?= e(t('enquiry_intro')) ?></p>
    </div>

    <?php if (!empty($errors['_form'])): ?>
      <div class="notice notice--error"><?= e($errors['_form']) ?></div>
    <?php endif; ?>

    <form class="form" method="post" action="<?= e(url('/enquiry')) ?>" novalidate>
      <?= csrf_field() ?>
      <input type="hidden" name="_started" value="<?= e((string) time()) ?>">
      <div class="honey" aria-hidden="true">
        <label for="website_url">Leave this empty</label>
        <input type="text" id="website_url" name="website_url" tabindex="-1" autocomplete="off">
      </div>

      <div class="field">
        <label class="field__label" for="package_id"><?= e(t('f_package')) ?></label>
        <select class="select" id="package_id" name="package_id">
          <option value=""><?= e(t('f_no_package')) ?></option>
          <?php foreach ($grouped as $group): ?>
            <optgroup label="<?= e(tr($group['category'], 'name')) ?>">
              <?php foreach ($group['packages'] as $p): ?>
                <option value="<?= (int) $p['id'] ?>" <?= $selectedPackage === (int) $p['id'] ? 'selected' : '' ?>>
                  <?= e(tr($p, 'name')) ?> — <?= e(money((float) $p['price'], $p['currency'])) ?>
                </option>
              <?php endforeach; ?>
            </optgroup>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form form--split" style="gap:1.15rem">
        <div class="field">
          <label class="field__label" for="name">
            <?= e(t('f_name')) ?> <span class="field__req" aria-hidden="true">*</span>
          </label>
          <input class="input <?= isset($errors['name']) ? 'input--error' : '' ?>"
                 type="text" id="name" name="name" required maxlength="140"
                 autocomplete="name"
                 value="<?= e(old('name')) ?>"
                 <?= isset($errors['name']) ? 'aria-describedby="err-name" aria-invalid="true"' : '' ?>>
          <?php if (isset($errors['name'])): ?>
            <span class="field__error" id="err-name"><?= e($errors['name']) ?></span>
          <?php endif; ?>
        </div>

        <div class="field">
          <label class="field__label" for="phone">
            <?= e(t('f_phone')) ?> <span class="field__req" aria-hidden="true">*</span>
          </label>
          <input class="input <?= isset($errors['phone']) ? 'input--error' : '' ?>"
                 type="tel" id="phone" name="phone" required maxlength="40"
                 inputmode="tel" autocomplete="tel"
                 value="<?= e(old('phone')) ?>"
                 <?= isset($errors['phone']) ? 'aria-describedby="err-phone" aria-invalid="true"' : '' ?>>
          <?php if (isset($errors['phone'])): ?>
            <span class="field__error" id="err-phone"><?= e($errors['phone']) ?></span>
          <?php endif; ?>
        </div>

        <div class="field">
          <label class="field__label" for="email"><?= e(t('f_email')) ?></label>
          <input class="input <?= isset($errors['email']) ? 'input--error' : '' ?>"
                 type="email" id="email" name="email" maxlength="190"
                 inputmode="email" autocomplete="email"
                 value="<?= e(old('email')) ?>"
                 <?= isset($errors['email']) ? 'aria-describedby="err-email" aria-invalid="true"' : '' ?>>
          <?php if (isset($errors['email'])): ?>
            <span class="field__error" id="err-email"><?= e($errors['email']) ?></span>
          <?php endif; ?>
        </div>

        <div class="field">
          <label class="field__label" for="company"><?= e(t('f_company')) ?></label>
          <input class="input" type="text" id="company" name="company" maxlength="160"
                 autocomplete="organization" value="<?= e(old('company')) ?>">
        </div>
      </div>

      <div class="field">
        <label class="field__label" for="message"><?= e(t('f_message')) ?></label>
        <textarea class="textarea" id="message" name="message" maxlength="4000"
                  rows="5"><?= e(old('message')) ?></textarea>
      </div>

      <div class="form__actions">
        <button class="btn btn--accent btn--auto" type="submit"><?= e(t('f_submit')) ?></button>
        <span class="field__hint" style="align-self:center"><?= e(t('f_required_note')) ?></span>
      </div>
    </form>
  </div>
</section>
<?php clear_old(); ?>
