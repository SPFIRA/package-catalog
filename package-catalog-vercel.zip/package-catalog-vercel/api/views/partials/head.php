<?php
/** @var string $title */
/** @var string|null $metaDescription */
$title = $title ?? setting('site_name', 'Packages');
?>
<!DOCTYPE html>
<html lang="<?= e(html_lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> — <?= e(setting('site_name', 'Packages')) ?></title>
<meta name="description" content="<?= e($metaDescription ?? setting('tagline')) ?>">
<meta name="theme-color" content="#0E3529">
<meta property="og:title" content="<?= e($title) ?>">
<meta property="og:description" content="<?= e($metaDescription ?? setting('tagline')) ?>">
<meta property="og:type" content="website">
<link rel="stylesheet" href="<?= e(asset('assets/css/style.css')) ?>">
<script src="<?= e(asset('assets/js/app.js')) ?>" defer></script>
</head>
<body>
<a class="skip" href="#main"><?= e(t('skip_to_content')) ?></a>

<header class="masthead">
  <div class="shell masthead__bar">
    <a class="brand" href="<?= e(url('/')) ?>">
      <span class="brand__mark" aria-hidden="true">◆</span>
      <?= e(setting('site_name', 'Packages')) ?>
    </a>

    <nav class="masthead__nav" aria-label="<?= e(t('nav_packages')) ?>">
      <a class="navlink" href="<?= e(url('/')) ?>"><?= e(t('nav_packages')) ?></a>
      <a class="navlink" href="<?= e(url('/#enquiry')) ?>"><?= e(t('nav_contact')) ?></a>

      <div class="langbar" role="group" aria-label="<?= e(t('language')) ?>">
        <?php foreach (LANGS as $code => $label): ?>
          <a class="langbar__item <?= current_lang() === $code ? 'langbar__item--on' : '' ?>"
             href="<?= e(lang_switch_url($code)) ?>"
             lang="<?= e($code) ?>"
             <?= current_lang() === $code ? 'aria-current="true"' : '' ?>><?= e($label) ?></a>
        <?php endforeach; ?>
      </div>
    </nav>
  </div>
</header>

<main id="main">
<?php foreach (flash_take() as $msg): ?>
  <div class="shell" style="padding-top:1.25rem">
    <div class="notice notice--<?= e($msg['type']) ?>"><?= e($msg['message']) ?></div>
  </div>
<?php endforeach; ?>
