</main>

<footer class="footer">
  <div class="shell footer__row">
    <div>
      <p class="footer__note"><strong><?= e(setting('site_name')) ?></strong><br>
        <?= e(setting('footer_note')) ?></p>
      <p class="footer__note" style="margin-top:.75rem"><?= e(setting('quote_validity')) ?></p>
    </div>
    <div class="footer__links">
      <?php if (setting('phone')): ?>
        <a href="tel:<?= e(preg_replace('/[^0-9+]/', '', setting('phone'))) ?>"><?= e(setting('phone')) ?></a>
      <?php endif; ?>
      <?php if (setting('email')): ?>
        <a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a>
      <?php endif; ?>
      <?php if (setting('telegram')): ?>
        <a href="<?= e(setting('telegram')) ?>" rel="noopener noreferrer">Telegram</a>
      <?php endif; ?>
    </div>
  </div>
</footer>
</body>
</html>
