<?php
/** @var array $errors @var bool $done @var int $users @var string $token */
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Setup</title>
<link rel="stylesheet" href="<?= e(asset('assets/css/style.css')) ?>">
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <h1 class="login-card__title">Create your admin account</h1>

    <?php if ($done): ?>
      <div class="notice notice--ok">
        Account created. Now do both of these:<br><br>
        1. Delete the <code>SETUP_TOKEN</code> variable in Vercel and redeploy —
           this page then returns 404 permanently.<br>
        2. Sign in at <a href="<?= e(admin_url('login')) ?>"><?= e(admin_url('login')) ?></a>
      </div>
    <?php else: ?>

      <?php if (!empty($errors['_form'])): ?>
        <div class="notice notice--error"><?= e($errors['_form']) ?></div>
      <?php endif; ?>

      <?php if ($users === 0): ?>
        <form class="form" method="post" action="<?= e(url('/setup')) ?>" novalidate>
          <?= csrf_field() ?>
          <input type="hidden" name="token" value="<?= e($token) ?>">
          <div class="field">
            <label class="field__label" for="name">Your name</label>
            <input class="input" id="name" name="name" required maxlength="120"
                   value="<?= e((string) ($_POST['name'] ?? '')) ?>">
            <?php if (isset($errors['name'])): ?><span class="field__error"><?= e($errors['name']) ?></span><?php endif; ?>
          </div>
          <div class="field">
            <label class="field__label" for="email">Email</label>
            <input class="input" type="email" id="email" name="email" required maxlength="190"
                   autocomplete="username" value="<?= e((string) ($_POST['email'] ?? '')) ?>">
            <?php if (isset($errors['email'])): ?><span class="field__error"><?= e($errors['email']) ?></span><?php endif; ?>
          </div>
          <div class="field">
            <label class="field__label" for="password">Password</label>
            <input class="input" type="password" id="password" name="password" required
                   minlength="12" autocomplete="new-password">
            <span class="field__hint">At least 12 characters. Use a passphrase you have not used elsewhere.</span>
            <?php if (isset($errors['password'])): ?><span class="field__error"><?= e($errors['password']) ?></span><?php endif; ?>
          </div>
          <div class="field">
            <label class="field__label" for="password_confirm">Repeat password</label>
            <input class="input" type="password" id="password_confirm" name="password_confirm" required
                   autocomplete="new-password">
            <?php if (isset($errors['password_confirm'])): ?><span class="field__error"><?= e($errors['password_confirm']) ?></span><?php endif; ?>
          </div>
          <button class="btn btn--primary" type="submit">Create account</button>
        </form>
      <?php endif; ?>

    <?php endif; ?>
  </div>
</div>
</body>
</html>
