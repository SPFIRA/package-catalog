<?php
/** @var int $code */
$code  = $code ?? 404;
$title = $code === 404 ? t('e_404_heading') : t('e_500_heading');
require __DIR__ . '/partials/head.php';
?>
<section class="band">
  <div class="shell" style="max-width:600px">
    <p class="eyebrow"><?= (int) $code ?></p>
    <h1 class="band__title display"><?= e($title) ?></h1>
    <p class="band__lede"><?= e($code === 404 ? t('e_404_body') : t('e_500_body')) ?></p>
    <p style="margin-top:1.5rem">
      <a class="btn btn--primary btn--auto" href="<?= e(url('/')) ?>"><?= e(t('back_to_all')) ?></a>
    </p>
  </div>
</section>
<?php require __DIR__ . '/partials/foot.php'; ?>
