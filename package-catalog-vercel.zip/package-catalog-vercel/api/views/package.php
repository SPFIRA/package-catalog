<?php
/**
 * @var array $category
 * @var array $package
 * @var array $features   each with is_included / value_en / value_am merged in
 * @var array $addons
 * @var array $grouped
 * @var array $errors
 */
$title           = tr($package, 'name') . ' — ' . tr($category, 'name');
$metaDescription = tr($package, 'summary') ?: tr($package, 'tagline');
$selectedPackage = (int) $package['id'];
require __DIR__ . '/partials/head.php';
?>

<section class="hero">
  <div class="shell">
    <p class="crumb" style="color:#A9BFB2">
      <a href="<?= e(url('/')) ?>" style="color:#A9BFB2"><?= e(t('back_to_all')) ?></a>
      <span aria-hidden="true">&nbsp;/&nbsp;</span>
      <a href="<?= e(url('/c/' . $category['slug'])) ?>" style="color:#A9BFB2"><?= e(tr($category, 'name')) ?></a>
      <span aria-hidden="true">&nbsp;/&nbsp;</span> <?= e(tr($package, 'name')) ?>
    </p>
    <p class="eyebrow"><?= e(t('ref')) ?> <?= e(package_ref($category, $package)) ?></p>
    <h1 class="hero__title display"><?= e(tr($package, 'name')) ?></h1>
    <p class="hero__sub"><?= e(tr($package, 'tagline')) ?></p>

    <div class="hero__meta">
      <div class="hero__stat">
        <span class="hero__stat-k"><?= e(money((float) $package['price'], $package['currency'])) ?></span>
        <span class="hero__stat-v"><?= e(tr($package, 'price_note') ?: t('a_price')) ?></span>
      </div>
      <?php if ($package['delivery_days']): ?>
      <div class="hero__stat">
        <span class="hero__stat-k"><?= (int) $package['delivery_days'] ?></span>
        <span class="hero__stat-v"><?= e(t('delivery')) ?></span>
      </div>
      <?php endif; ?>
      <?php if ($package['support_months']): ?>
      <div class="hero__stat">
        <span class="hero__stat-k"><?= (int) $package['support_months'] ?></span>
        <span class="hero__stat-v"><?= e(t('support')) ?></span>
      </div>
      <?php endif; ?>
      <?php if ($package['revision_rounds']): ?>
      <div class="hero__stat">
        <span class="hero__stat-k"><?= (int) $package['revision_rounds'] ?></span>
        <span class="hero__stat-v"><?= e(t('revisions')) ?></span>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<section class="band">
  <div class="shell">
    <div class="grid-2">
      <div>
        <?php if (tr($package, 'summary')): ?>
          <p style="font-size:1.1rem"><?= e(tr($package, 'summary')) ?></p>
        <?php endif; ?>
        <?php if (tr($package, 'description')): ?>
          <?php foreach (preg_split('/\R{2,}/', tr($package, 'description')) as $para): ?>
            <?php if (trim($para) !== ''): ?><p><?= nl2br(e(trim($para))) ?></p><?php endif; ?>
          <?php endforeach; ?>
        <?php endif; ?>

        <p style="margin-top:1.5rem">
          <a class="btn btn--accent btn--auto" href="#enquiry"><?= e(t('choose_package')) ?></a>
          <a class="btn btn--ghost btn--auto" href="<?= e(url('/c/' . $category['slug'])) ?>"><?= e(t('compare_heading')) ?></a>
        </p>
      </div>

      <div>
        <div class="panel">
          <h2 class="panel__title"><?= e(t('compare_heading')) ?></h2>
          <ul>
            <?php foreach ($features as $f): ?>
              <?php $included = (int) ($f['is_included'] ?? 0) === 1; $value = tr($f, 'value'); ?>
              <li class="spec" style="margin-bottom:.65rem">
                <span class="mark <?= $included ? 'mark--yes' : 'mark--no' ?>" aria-hidden="true"><?= $included ? '✓' : '–' ?></span>
                <span class="spec__k" style="white-space:normal;color:<?= $included ? 'var(--ink)' : 'var(--stone)' ?>">
                  <?= e(tr($f, 'label')) ?>
                </span>
                <span class="spec__dots" aria-hidden="true"></span>
                <?php if ($value !== ''): ?>
                  <span class="spec__v"><?= e($value) ?></span>
                <?php else: ?>
                  <span class="sr-only"><?= $included ? e(t('included')) : e(t('not_included')) ?></span>
                <?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<?php if ($addons): ?>
<section class="band band--surface band--tight">
  <div class="shell">
    <div class="band__head">
      <p class="eyebrow eyebrow--stone"><?= e(t('addons_heading')) ?></p>
      <h2 class="band__title display"><?= e(t('addons_intro')) ?></h2>
    </div>
    <div class="addons">
      <?php foreach ($addons as $a): ?>
        <article class="addon">
          <h3 class="addon__name"><?= e(tr($a, 'name')) ?></h3>
          <p class="addon__desc"><?= e(tr($a, 'description')) ?></p>
          <p class="addon__price">
            <?= e(money((float) $a['price'], $a['currency'])) ?>
            <span class="addon__cycle"><?= e(t('billing_' . $a['billing_cycle'])) ?></span>
          </p>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php
require __DIR__ . '/partials/enquiry_form.php';
require __DIR__ . '/partials/foot.php';
