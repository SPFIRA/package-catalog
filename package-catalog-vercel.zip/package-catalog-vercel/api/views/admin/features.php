<?php
/** @var array $categories @var int $catId @var array $rows @var array $errors */
$adminTitle = t('a_features'); $here = 'features';
require __DIR__ . '/head.php';
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e(t('a_features')) ?></h1>
</div>

<div class="notice notice--warn"><?= e(t('a_features_help')) ?></div>

<form class="panel" method="get" action="<?= e(admin_url('features')) ?>">
  <div class="field" style="max-width:320px">
    <label class="field__label" for="category"><?= e(t('a_category')) ?></label>
    <select class="select" id="category" name="category" data-autosubmit>
      <?php foreach ($categories as $c): ?>
        <option value="<?= (int) $c['id'] ?>" <?= $catId === (int) $c['id'] ? 'selected' : '' ?>>
          <?= e($c['name_en']) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <span data-js-hide><button class="btn btn--ghost btn--sm btn--auto" type="submit" style="margin-top:.5rem"><?= e(t('a_search')) ?></button></span>
  </div>
</form>

<?php if ($catId): ?>

  <div class="panel">
    <h2 class="panel__title"><?= e(t('a_new')) ?></h2>
    <form class="form" method="post" action="<?= e(admin_url('features/save')) ?>" novalidate>
      <?= csrf_field() ?>
      <input type="hidden" name="category_id" value="<?= (int) $catId ?>">
      <div class="grid-3">
        <div class="field">
          <label class="field__label" for="label_en"><?= e(t('a_label')) ?> — <?= e(t('a_english')) ?> <span class="field__req">*</span></label>
          <input class="input <?= isset($errors['label_en']) ? 'input--error' : '' ?>" id="label_en" name="label_en" required maxlength="180">
        </div>
        <div class="field">
          <label class="field__label" for="label_am"><?= e(t('a_label')) ?> — <?= e(t('a_amharic')) ?> <span class="field__req">*</span></label>
          <input class="input <?= isset($errors['label_am']) ? 'input--error' : '' ?>" id="label_am" name="label_am" required maxlength="180" lang="am">
        </div>
        <div class="field">
          <label class="field__label" for="sort_order"><?= e(t('a_order')) ?></label>
          <input class="input" type="number" id="sort_order" name="sort_order" value="<?= count($rows) + 1 ?>">
        </div>
      </div>
      <div class="form__actions">
        <button class="btn btn--primary btn--auto" type="submit"><?= e(t('a_save')) ?></button>
      </div>
    </form>
  </div>

  <?php if (!$rows): ?>
    <p class="empty"><?= e(t('a_no_rows')) ?></p>
  <?php else: ?>
    <form method="post" action="<?= e(admin_url('features/save_all')) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="category_id" value="<?= (int) $catId ?>">

      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th class="table__num" style="width:90px"><?= e(t('a_order')) ?></th>
              <th><?= e(t('a_english')) ?></th>
              <th><?= e(t('a_amharic')) ?></th>
              <th style="width:110px"></th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($rows as $r): $fid = (int) $r['id']; ?>
            <tr>
              <td class="table__num">
                <input class="input" type="number" style="width:80px"
                       name="f[<?= $fid ?>][sort_order]" value="<?= (int) $r['sort_order'] ?>"
                       aria-label="<?= e(t('a_order')) ?>">
              </td>
              <td>
                <input class="input" name="f[<?= $fid ?>][label_en]" maxlength="180" required
                       value="<?= e($r['label_en']) ?>" aria-label="<?= e(t('a_english')) ?>">
              </td>
              <td>
                <input class="input" name="f[<?= $fid ?>][label_am]" maxlength="180" required lang="am"
                       value="<?= e($r['label_am']) ?>" aria-label="<?= e(t('a_amharic')) ?>">
              </td>
              <td>
                <button class="btn btn--danger btn--sm btn--auto" type="submit"
                        formaction="<?= e(admin_url('features/delete')) ?>"
                        name="id" value="<?= $fid ?>" formnovalidate
                        data-confirm="<?= e(t('a_confirm_delete')) ?>">
                  <?= e(t('a_delete')) ?>
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="form__actions">
        <button class="btn btn--primary btn--auto" type="submit"><?= e(t('a_save')) ?></button>
      </div>
    </form>
  <?php endif; ?>

<?php endif; ?>
<?php clear_old(); require __DIR__ . '/foot.php'; ?>
