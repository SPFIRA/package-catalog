<?php
/** @var array $stats @var array $recent */
$adminTitle = t('a_dashboard');
$here = '';
require __DIR__ . '/head.php';
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e(t('a_dashboard')) ?></h1>
  <a class="btn btn--accent btn--sm btn--auto" href="<?= e(admin_url('packages/new')) ?>"><?= e(t('a_new')) ?></a>
</div>

<div class="stats">
  <div class="stat stat--accent">
    <div class="stat__n"><?= (int) $stats['new_inquiries'] ?></div>
    <div class="stat__k"><?= e(t('a_new_enquiries')) ?></div>
  </div>
  <div class="stat">
    <div class="stat__n"><?= (int) $stats['packages'] ?></div>
    <div class="stat__k"><?= e(t('a_total_packages')) ?></div>
  </div>
  <div class="stat">
    <div class="stat__n"><?= (int) $stats['categories'] ?></div>
    <div class="stat__k"><?= e(t('a_total_categories')) ?></div>
  </div>
  <div class="stat">
    <div class="stat__n" style="font-size:1.25rem"><?= e(money((float) $stats['won_value'])) ?></div>
    <div class="stat__k"><?= e(t('a_won_value')) ?></div>
  </div>
</div>

<div class="panel">
  <h2 class="panel__title"><?= e(t('a_recent')) ?></h2>
  <?php if (!$recent): ?>
    <p class="empty"><?= e(t('a_no_rows')) ?></p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead><tr>
          <th><?= e(t('a_name')) ?></th><th><?= e(t('a_package')) ?></th>
          <th><?= e(t('a_phone')) ?></th><th><?= e(t('a_status')) ?></th>
          <th><?= e(t('a_created')) ?></th><th></th>
        </tr></thead>
        <tbody>
        <?php foreach ($recent as $r): ?>
          <tr>
            <td><?= e($r['name']) ?></td>
            <td><?= e($r['pkg_en'] ? tr($r, 'pkg') : '—') ?></td>
            <td><?= e($r['phone']) ?></td>
            <td><span class="pill pill--<?= $r['status'] === 'new' ? 'new' : ($r['status'] === 'won' ? 'won' : ($r['status'] === 'lost' ? 'lost' : 'off')) ?>"><?= e(t('s_' . $r['status'])) ?></span></td>
            <td><?= e(date('d M, H:i', strtotime($r['created_at']))) ?></td>
            <td><a class="btn btn--ghost btn--sm btn--auto" href="<?= e(admin_url('inquiries/show/' . (int) $r['id'])) ?>"><?= e(t('a_edit')) ?></a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/foot.php'; ?>
