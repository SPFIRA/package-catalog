<?php
/** @var array $rows */
$adminTitle = t('a_addons'); $here = 'addons';
require __DIR__ . '/head.php';
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e(t('a_addons')) ?></h1>
  <a class="btn btn--accent btn--sm btn--auto" href="<?= e(admin_url('addons/new')) ?>"><?= e(t('a_new')) ?></a>
</div>

<?php if (!$rows): ?>
  <p class="empty"><?= e(t('a_no_rows')) ?></p>
<?php else: ?>
<div class="table-wrap">
  <table class="table">
    <thead><tr>
      <th><?= e(t('a_name')) ?></th><th><?= e(t('a_category')) ?></th>
      <th class="table__num"><?= e(t('a_price')) ?></th><th><?= e(t('a_billing')) ?></th>
      <th><?= e(t('a_status')) ?></th><th></th>
    </tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?= e($r['name_en']) ?></strong><br><span style="color:var(--stone)"><?= e($r['name_am']) ?></span></td>
        <td><?= e($r['cat_en'] ?? t('a_all')) ?></td>
        <td class="table__num"><?= e(money((float) $r['price'], $r['currency'])) ?></td>
        <td><?= e(t('billing_' . $r['billing_cycle'])) ?></td>
        <td><span class="pill pill--<?= (int) $r['is_active'] ? 'on' : 'off' ?>"><?= e((int) $r['is_active'] ? t('a_active') : t('a_inactive')) ?></span></td>
        <td>
          <div class="table__actions">
            <a class="btn btn--ghost btn--sm btn--auto" href="<?= e(admin_url('addons/edit/' . (int) $r['id'])) ?>"><?= e(t('a_edit')) ?></a>
            <form class="inline-form" method="post" action="<?= e(admin_url('addons/delete')) ?>"
                  data-confirm="<?= e(t('a_confirm_delete')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
              <button class="btn btn--danger btn--sm btn--auto" type="submit"><?= e(t('a_delete')) ?></button>
            </form>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/foot.php'; ?>
