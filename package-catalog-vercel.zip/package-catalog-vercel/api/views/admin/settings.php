<?php
/** @var array $rows */
$adminTitle = t('a_settings'); $here = 'settings';
require __DIR__ . '/head.php';
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e(t('a_settings')) ?></h1>
</div>

<form class="panel" method="post" action="<?= e(admin_url('settings/save')) ?>">
  <?= csrf_field() ?>
  <?php foreach ($rows as $r): $k = (string) $r['key']; ?>
    <div class="grid-2" style="margin-bottom:1.15rem">
      <div class="field">
        <label class="field__label" for="s_<?= e($k) ?>_en"><?= e(str_replace('_', ' ', $k)) ?> — <?= e(t('a_english')) ?></label>
        <textarea class="textarea" style="min-height:80px" id="s_<?= e($k) ?>_en"
                  name="s[<?= e($k) ?>][en]" maxlength="5000"><?= e((string) $r['value_en']) ?></textarea>
      </div>
      <div class="field">
        <label class="field__label" for="s_<?= e($k) ?>_am"><?= e(str_replace('_', ' ', $k)) ?> — <?= e(t('a_amharic')) ?></label>
        <textarea class="textarea" style="min-height:80px" id="s_<?= e($k) ?>_am" lang="am"
                  name="s[<?= e($k) ?>][am]" maxlength="5000"><?= e((string) $r['value_am']) ?></textarea>
      </div>
    </div>
  <?php endforeach; ?>
  <div class="form__actions">
    <button class="btn btn--primary btn--auto" type="submit"><?= e(t('a_save')) ?></button>
  </div>
</form>
<?php require __DIR__ . '/foot.php'; ?>
