<?php
/** @var array $rows @var string $status */
$adminTitle = t('a_inquiries'); $here = 'inquiries';
require __DIR__ . '/head.php';
$pillFor = fn(string $s): string => $s === 'new' ? 'new' : ($s === 'won' ? 'won' : ($s === 'lost' ? 'lost' : 'off'));
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e(t('a_inquiries')) ?></h1>
</div>

<form class="panel" method="get" action="<?= e(admin_url('inquiries')) ?>">
  <div class="field" style="max-width:280px">
    <label class="field__label" for="status"><?= e(t('a_status')) ?></label>
    <select class="select" id="status" name="status" data-autosubmit>
      <option value=""><?= e(t('a_all')) ?></option>
      <?php foreach (['new','contacted','quoted','won','lost'] as $s): ?>
        <option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e(t('s_' . $s)) ?></option>
      <?php endforeach; ?>
    </select>
    <span data-js-hide><button class="btn btn--ghost btn--sm btn--auto" type="submit" style="margin-top:.5rem"><?= e(t('a_search')) ?></button></span>
  </div>
</form>

<?php if (!$rows): ?>
  <p class="empty"><?= e(t('a_no_rows')) ?></p>
<?php else: ?>
<div class="table-wrap">
  <table class="table">
    <thead><tr>
      <th><?= e(t('a_name')) ?></th><th><?= e(t('a_company')) ?></th><th><?= e(t('a_package')) ?></th>
      <th><?= e(t('a_phone')) ?></th><th><?= e(t('a_status')) ?></th><th><?= e(t('a_created')) ?></th><th></th>
    </tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?= e($r['name']) ?></strong></td>
        <td><?= e($r['company'] ?: '—') ?></td>
        <td><?= e($r['pkg_en'] ? tr($r, 'pkg') : '—') ?></td>
        <td><a href="tel:<?= e(preg_replace('/[^0-9+]/', '', $r['phone'])) ?>"><?= e($r['phone']) ?></a></td>
        <td><span class="pill pill--<?= e($pillFor($r['status'])) ?>"><?= e(t('s_' . $r['status'])) ?></span></td>
        <td><?= e(date('d M Y, H:i', strtotime($r['created_at']))) ?></td>
        <td><a class="btn btn--ghost btn--sm btn--auto" href="<?= e(admin_url('inquiries/show/' . (int) $r['id'])) ?>"><?= e(t('a_edit')) ?></a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/foot.php'; ?>
