<?php
/** @var array $row */
$adminTitle = t('a_inquiries'); $here = 'inquiries';
require __DIR__ . '/head.php';
$snap = $row['package_snapshot'] ? json_decode((string) $row['package_snapshot'], true) : null;
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e($row['name']) ?></h1>
  <a class="btn btn--ghost btn--sm btn--auto" href="<?= e(admin_url('inquiries')) ?>"><?= e(t('back')) ?></a>
</div>

<div class="grid-2">
  <div>
    <div class="panel">
      <h2 class="panel__title"><?= e(t('a_inquiries')) ?></h2>
      <p class="spec"><span class="spec__k"><?= e(t('a_phone')) ?></span><span class="spec__dots"></span>
         <span class="spec__v"><a href="tel:<?= e(preg_replace('/[^0-9+]/', '', $row['phone'])) ?>"><?= e($row['phone']) ?></a></span></p>
      <?php if ($row['email']): ?>
      <p class="spec"><span class="spec__k"><?= e(t('a_email')) ?></span><span class="spec__dots"></span>
         <span class="spec__v"><a href="mailto:<?= e($row['email']) ?>"><?= e($row['email']) ?></a></span></p>
      <?php endif; ?>
      <?php if ($row['company']): ?>
      <p class="spec"><span class="spec__k"><?= e(t('a_company')) ?></span><span class="spec__dots"></span>
         <span class="spec__v"><?= e($row['company']) ?></span></p>
      <?php endif; ?>
      <p class="spec"><span class="spec__k"><?= e(t('a_created')) ?></span><span class="spec__dots"></span>
         <span class="spec__v"><?= e(date('d M Y, H:i', strtotime($row['created_at']))) ?></span></p>
      <p class="spec"><span class="spec__k"><?= e(t('language')) ?></span><span class="spec__dots"></span>
         <span class="spec__v"><?= e(strtoupper($row['lang'])) ?></span></p>

      <?php if ($row['message']): ?>
        <h3 class="panel__title" style="margin-top:1.5rem"><?= e(t('a_message')) ?></h3>
        <p style="white-space:pre-wrap"><?= e($row['message']) ?></p>
      <?php endif; ?>
    </div>

    <form class="panel" method="post" action="<?= e(admin_url('inquiries/update')) ?>">
      <h2 class="panel__title"><?= e(t('a_status')) ?></h2>
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
      <div class="field">
        <label class="field__label" for="status"><?= e(t('a_status')) ?></label>
        <select class="select" id="status" name="status">
          <?php foreach (['new','contacted','quoted','won','lost'] as $s): ?>
            <option value="<?= e($s) ?>" <?= $row['status'] === $s ? 'selected' : '' ?>><?= e(t('s_' . $s)) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label class="field__label" for="admin_note"><?= e(t('a_note')) ?></label>
        <textarea class="textarea" id="admin_note" name="admin_note" maxlength="4000"><?= e((string) $row['admin_note']) ?></textarea>
      </div>
      <div class="form__actions">
        <button class="btn btn--primary btn--auto" type="submit"><?= e(t('a_save')) ?></button>
      </div>
    </form>

    <form class="panel" method="post" action="<?= e(admin_url('inquiries/delete')) ?>"
          data-confirm="<?= e(t('a_confirm_delete')) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
      <button class="btn btn--danger btn--sm btn--auto" type="submit"><?= e(t('a_delete')) ?></button>
    </form>
  </div>

  <div>
    <div class="panel">
      <h2 class="panel__title"><?= e(t('a_snapshot')) ?></h2>
      <?php if (!$snap): ?>
        <p class="empty"><?= e(t('a_none')) ?></p>
      <?php else: ?>
        <p class="spec"><span class="spec__k"><?= e(t('ref')) ?></span><span class="spec__dots"></span>
           <span class="spec__v"><?= e((string) ($snap['ref'] ?? '—')) ?></span></p>
        <p class="spec"><span class="spec__k"><?= e(t('a_package')) ?></span><span class="spec__dots"></span>
           <span class="spec__v"><?= e((string) ($snap['package'] ?? '—')) ?></span></p>
        <p class="spec"><span class="spec__k"><?= e(t('a_price')) ?></span><span class="spec__dots"></span>
           <span class="spec__v"><?= e(money((float) ($snap['price'] ?? 0), (string) ($snap['currency'] ?? 'ETB'))) ?></span></p>
        <p class="field__hint" style="margin-bottom:1rem">
          Frozen at <?= e(date('d M Y, H:i', strtotime((string) ($snap['quoted_at'] ?? $row['created_at'])))) ?>.
          Editing the package now will not change this.
        </p>
        <ul>
          <?php foreach ((array) ($snap['features'] ?? []) as $f): ?>
            <li class="spec" style="margin-bottom:.5rem">
              <span class="mark <?= !empty($f['included']) ? 'mark--yes' : 'mark--no' ?>"><?= !empty($f['included']) ? '✓' : '–' ?></span>
              <span class="spec__k" style="white-space:normal"><?= e((string) $f['label']) ?></span>
              <span class="spec__dots"></span>
              <?php if (!empty($f['value'])): ?><span class="spec__v"><?= e((string) $f['value']) ?></span><?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require __DIR__ . '/foot.php'; ?>
