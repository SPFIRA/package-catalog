<?php
/**
 * @var array|null $package @var array $categories @var array $features
 * @var array $assigned @var int $catId @var array $errors
 */
$isEdit = $package !== null;
$adminTitle = $isEdit ? t('a_edit') : t('a_new'); $here = 'packages';
$val = function (string $k, string $d = '') use ($package) {
    $o = old($k); return $o !== '' ? $o : (string) ($package[$k] ?? $d);
};
require __DIR__ . '/head.php';
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e($adminTitle) ?> — <?= e(t('a_packages')) ?></h1>
  <a class="btn btn--ghost btn--sm btn--auto" href="<?= e(admin_url('packages')) ?>"><?= e(t('a_cancel')) ?></a>
</div>

<?php if (!$isEdit && !$catId): ?>
  <div class="panel">
    <h2 class="panel__title"><?= e(t('a_category')) ?></h2>
    <form method="get" action="<?= e(admin_url('packages/new')) ?>">
      <div class="field" style="max-width:340px">
        <label class="field__label" for="pickcat"><?= e(t('a_category')) ?></label>
        <select class="select" id="pickcat" name="category" required>
          <option value=""><?= e(t('a_none')) ?></option>
          <?php foreach ($categories as $c): ?>
            <option value="<?= (int) $c['id'] ?>"><?= e($c['name_en']) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field__hint">Choose the category first so the feature rows load.</span>
      </div>
      <div class="form__actions"><button class="btn btn--primary btn--auto" type="submit"><?= e(t('a_new')) ?></button></div>
    </form>
  </div>
<?php else: ?>

<form method="post" action="<?= e(admin_url('packages/save')) ?>" novalidate>
  <?= csrf_field() ?>
  <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= (int) $package['id'] ?>"><?php endif; ?>
  <input type="hidden" name="category_id" value="<?= (int) $catId ?>">

  <div class="panel">
    <h2 class="panel__title"><?= e(t('a_name')) ?></h2>
    <div class="grid-2">
      <div class="field">
        <label class="field__label" for="name_en"><?= e(t('a_name')) ?> — <?= e(t('a_english')) ?> <span class="field__req">*</span></label>
        <input class="input <?= isset($errors['name_en']) ? 'input--error' : '' ?>" id="name_en" name="name_en" required maxlength="120" value="<?= e($val('name_en')) ?>">
        <?php if (isset($errors['name_en'])): ?><span class="field__error"><?= e($errors['name_en']) ?></span><?php endif; ?>
      </div>
      <div class="field">
        <label class="field__label" for="name_am"><?= e(t('a_name')) ?> — <?= e(t('a_amharic')) ?> <span class="field__req">*</span></label>
        <input class="input <?= isset($errors['name_am']) ? 'input--error' : '' ?>" id="name_am" name="name_am" required maxlength="120" lang="am" value="<?= e($val('name_am')) ?>">
        <?php if (isset($errors['name_am'])): ?><span class="field__error"><?= e($errors['name_am']) ?></span><?php endif; ?>
      </div>
      <div class="field">
        <label class="field__label" for="tagline_en"><?= e(t('a_tagline')) ?> — <?= e(t('a_english')) ?></label>
        <input class="input" id="tagline_en" name="tagline_en" maxlength="200" value="<?= e($val('tagline_en')) ?>">
      </div>
      <div class="field">
        <label class="field__label" for="tagline_am"><?= e(t('a_tagline')) ?> — <?= e(t('a_amharic')) ?></label>
        <input class="input" id="tagline_am" name="tagline_am" maxlength="200" lang="am" value="<?= e($val('tagline_am')) ?>">
      </div>
      <div class="field">
        <label class="field__label" for="summary_en"><?= e(t('a_summary')) ?> — <?= e(t('a_english')) ?></label>
        <textarea class="textarea" id="summary_en" name="summary_en" maxlength="2000"><?= e($val('summary_en')) ?></textarea>
      </div>
      <div class="field">
        <label class="field__label" for="summary_am"><?= e(t('a_summary')) ?> — <?= e(t('a_amharic')) ?></label>
        <textarea class="textarea" id="summary_am" name="summary_am" maxlength="2000" lang="am"><?= e($val('summary_am')) ?></textarea>
      </div>
      <div class="field">
        <label class="field__label" for="description_en"><?= e(t('a_description')) ?> — <?= e(t('a_english')) ?></label>
        <textarea class="textarea" id="description_en" name="description_en" maxlength="20000"><?= e($val('description_en')) ?></textarea>
      </div>
      <div class="field">
        <label class="field__label" for="description_am"><?= e(t('a_description')) ?> — <?= e(t('a_amharic')) ?></label>
        <textarea class="textarea" id="description_am" name="description_am" maxlength="20000" lang="am"><?= e($val('description_am')) ?></textarea>
      </div>
    </div>
  </div>

  <div class="panel">
    <h2 class="panel__title"><?= e(t('a_price')) ?></h2>
    <div class="grid-3">
      <div class="field">
        <label class="field__label" for="price"><?= e(t('a_price')) ?> <span class="field__req">*</span></label>
        <input class="input <?= isset($errors['price']) ? 'input--error' : '' ?>" type="number" step="0.01" min="0" id="price" name="price" required value="<?= e($val('price', '0')) ?>">
        <?php if (isset($errors['price'])): ?><span class="field__error"><?= e($errors['price']) ?></span><?php endif; ?>
      </div>
      <div class="field">
        <label class="field__label" for="currency"><?= e(t('a_currency')) ?> <span class="field__req">*</span></label>
        <input class="input" id="currency" name="currency" required maxlength="8" value="<?= e($val('currency', 'ETB')) ?>">
      </div>
      <div class="field">
        <label class="field__label" for="sort_order"><?= e(t('a_order')) ?></label>
        <input class="input" type="number" id="sort_order" name="sort_order" value="<?= e($val('sort_order', '0')) ?>">
      </div>
      <div class="field">
        <label class="field__label" for="price_note_en"><?= e(t('a_price_note')) ?> — <?= e(t('a_english')) ?></label>
        <input class="input" id="price_note_en" name="price_note_en" maxlength="120" value="<?= e($val('price_note_en')) ?>" placeholder="one-time">
      </div>
      <div class="field">
        <label class="field__label" for="price_note_am"><?= e(t('a_price_note')) ?> — <?= e(t('a_amharic')) ?></label>
        <input class="input" id="price_note_am" name="price_note_am" maxlength="120" lang="am" value="<?= e($val('price_note_am')) ?>">
      </div>
      <div class="field">
        <label class="field__label" for="slug"><?= e(t('a_slug')) ?></label>
        <input class="input" id="slug" name="slug" maxlength="80" value="<?= e($val('slug')) ?>" placeholder="professional">
      </div>
      <div class="field">
        <label class="field__label" for="delivery_days"><?= e(t('a_delivery_days')) ?></label>
        <input class="input" type="number" min="0" max="3650" id="delivery_days" name="delivery_days" value="<?= e($val('delivery_days')) ?>">
      </div>
      <div class="field">
        <label class="field__label" for="revision_rounds"><?= e(t('a_revisions')) ?></label>
        <input class="input" type="number" min="0" max="99" id="revision_rounds" name="revision_rounds" value="<?= e($val('revision_rounds')) ?>">
      </div>
      <div class="field">
        <label class="field__label" for="support_months"><?= e(t('a_support_months')) ?></label>
        <input class="input" type="number" min="0" max="99" id="support_months" name="support_months" value="<?= e($val('support_months')) ?>">
      </div>
    </div>

    <div style="display:flex;gap:1.5rem;flex-wrap:wrap;margin-top:1rem">
      <label class="check">
        <input type="checkbox" name="is_featured" value="1" <?= ($isEdit && (int) $package['is_featured']) ? 'checked' : '' ?>>
        <?= e(t('a_featured')) ?>
      </label>
      <label class="check">
        <input type="checkbox" name="is_active" value="1" <?= (!$isEdit || (int) $package['is_active']) ? 'checked' : '' ?>>
        <?= e(t('a_active')) ?>
      </label>
    </div>
  </div>

  <div class="panel">
    <h2 class="panel__title"><?= e(t('a_features')) ?></h2>
    <?php if (!$features): ?>
      <p class="empty">
        <?= e(t('a_no_rows')) ?>
        <a href="<?= e(admin_url('features?category=' . (int) $catId)) ?>"><?= e(t('a_features')) ?></a>
      </p>
    <?php else: ?>
      <p class="field__hint" style="margin-bottom:1rem"><?= e(t('a_matrix_help')) ?></p>
      <div class="table-wrap">
        <table class="matrix">
          <thead>
            <tr>
              <th style="width:44%"><?= e(t('feature')) ?></th>
              <th style="width:90px"><?= e(t('included')) ?></th>
              <th><?= e(t('a_value')) ?> — <?= e(t('a_english')) ?></th>
              <th><?= e(t('a_value')) ?> — <?= e(t('a_amharic')) ?></th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($features as $f): $fid = (int) $f['id']; $row = $assigned[$fid] ?? null; ?>
            <tr>
              <th scope="row" style="font-weight:400"><?= e($f['label_en']) ?></th>
              <td>
                <input type="checkbox" name="feat[<?= $fid ?>][on]" value="1"
                       style="width:20px;height:20px;accent-color:var(--forest)"
                       aria-label="<?= e($f['label_en']) ?>"
                       <?= ($row && (int) $row['is_included']) ? 'checked' : '' ?>>
              </td>
              <td><input class="input" name="feat[<?= $fid ?>][en]" maxlength="120"
                         value="<?= e($row['value_en'] ?? '') ?>" placeholder="—"
                         aria-label="<?= e($f['label_en']) ?> value English"></td>
              <td><input class="input" name="feat[<?= $fid ?>][am]" maxlength="120" lang="am"
                         value="<?= e($row['value_am'] ?? '') ?>" placeholder="—"
                         aria-label="<?= e($f['label_en']) ?> value Amharic"></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="form__actions">
    <button class="btn btn--primary btn--auto" type="submit"><?= e(t('a_save')) ?></button>
    <a class="btn btn--ghost btn--auto" href="<?= e(admin_url('packages')) ?>"><?= e(t('a_cancel')) ?></a>
  </div>
</form>
<?php endif; ?>
<?php clear_old(); require __DIR__ . '/foot.php'; ?>
