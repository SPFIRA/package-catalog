<?php /** @var string|null $error */ ?>
<!DOCTYPE html>
<html lang="<?= e(html_lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(t('login_heading')) ?></title>
<link rel="stylesheet" href="<?= e(asset('assets/css/style.css')) ?>">
<script src="<?= e(asset('assets/js/app.js')) ?>" defer></script>
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <h1 class="login-card__title"><?= e(t('login_heading')) ?></h1>

    <?php if ($error): ?>
      <div class="notice notice--error" role="alert"><?= e($error) ?></div>
    <?php endif; ?>

    <form class="form" method="post" action="<?= e(admin_url('login')) ?>" novalidate>
      <?= csrf_field() ?>
      <div class="field">
        <label class="field__label" for="email"><?= e(t('login_email')) ?></label>
        <input class="input" type="email" id="email" name="email" required
               autocomplete="username" autofocus value="<?= e(old('email')) ?>">
      </div>
      <div class="field">
        <label class="field__label" for="password"><?= e(t('login_password')) ?></label>
        <input class="input" type="password" id="password" name="password" required
               autocomplete="current-password">
      </div>
      <button class="btn btn--primary" type="submit"><?= e(t('login_submit')) ?></button>
    </form>
  </div>
</div>
<?php clear_old(); ?>
</body>
</html>
