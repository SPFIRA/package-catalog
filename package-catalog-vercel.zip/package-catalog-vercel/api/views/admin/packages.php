<?php
/** @var array $rows @var array $categories @var int $filter */
$adminTitle = t('a_packages'); $here = 'packages';
require __DIR__ . '/head.php';
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e(t('a_packages')) ?></h1>
  <a class="btn btn--accent btn--sm btn--auto" href="<?= e(admin_url('packages/new')) ?>"><?= e(t('a_new')) ?></a>
</div>

<form class="panel" method="get" action="<?= e(admin_url('packages')) ?>">
  <div class="field" style="max-width:320px">
    <label class="field__label" for="category"><?= e(t('a_category')) ?></label>
    <select class="select" id="category" name="category" data-autosubmit>
      <option value="0"><?= e(t('a_all')) ?></option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= (int) $c['id'] ?>" <?= $filter === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name_en']) ?></option>
      <?php endforeach; ?>
    </select>
    <span data-js-hide><button class="btn btn--ghost btn--sm btn--auto" type="submit" style="margin-top:.5rem"><?= e(t('a_search')) ?></button></span>
  </div>
</form>

<?php if (!$rows): ?>
  <p class="empty"><?= e(t('a_no_rows')) ?></p>
<?php else: ?>
<div class="table-wrap">
  <table class="table">
    <thead><tr>
      <th><?= e(t('a_name')) ?></th><th><?= e(t('a_category')) ?></th>
      <th class="table__num"><?= e(t('a_price')) ?></th>
      <th class="table__num"><?= e(t('a_order')) ?></th>
      <th><?= e(t('a_status')) ?></th><th></th>
    </tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td>
          <strong><?= e($r['name_en']) ?></strong>
          <?php if ((int) $r['is_featured']): ?> <span class="pill pill--new"><?= e(t('most_chosen')) ?></span><?php endif; ?>
          <br><span style="color:var(--stone)"><?= e($r['name_am']) ?></span>
        </td>
        <td><?= e($r['cat_en']) ?></td>
        <td class="table__num"><?= e(money((float) $r['price'], $r['currency'])) ?></td>
        <td class="table__num"><?= (int) $r['sort_order'] ?></td>
        <td><span class="pill pill--<?= (int) $r['is_active'] ? 'on' : 'off' ?>"><?= e((int) $r['is_active'] ? t('a_active') : t('a_inactive')) ?></span></td>
        <td>
          <div class="table__actions">
            <a class="btn btn--ghost btn--sm btn--auto" href="<?= e(admin_url('packages/edit/' . (int) $r['id'])) ?>"><?= e(t('a_edit')) ?></a>
            <a class="btn btn--ghost btn--sm btn--auto" href="<?= e(url('/p/' . $r['cat_slug'] . '/' . $r['slug'])) ?>" target="_blank" rel="noopener"><?= e(t('a_view_site')) ?></a>
            <form class="inline-form" method="post" action="<?= e(admin_url('packages/delete')) ?>"
                  data-confirm="<?= e(t('a_confirm_delete')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
              <button class="btn btn--danger btn--sm btn--auto" type="submit"><?= e(t('a_delete')) ?></button>
            </form>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/foot.php'; ?>
