<?php
/** @var array|null $user */
$adminTitle = $adminTitle ?? t('a_dashboard');
$here       = $here ?? '';
?>
<!DOCTYPE html>
<html lang="<?= e(html_lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($adminTitle) ?> — <?= e(setting('site_name', 'Admin')) ?></title>
<link rel="stylesheet" href="<?= e(asset('assets/css/style.css')) ?>">
<script src="<?= e(asset('assets/js/app.js')) ?>" defer></script>
</head>
<body class="admin">
<a class="skip" href="#admin-main"><?= e(t('skip_to_content')) ?></a>

<header class="admin__bar">
  <div class="shell admin__bar-inner">
    <a class="admin__brand" href="<?= e(admin_url('')) ?>"><?= e(setting('site_name', 'Admin')) ?></a>
    <nav class="admin__nav" aria-label="<?= e(t('a_dashboard')) ?>">
      <?php
      $links = [
        ''           => t('a_dashboard'),
        'categories' => t('a_categories'),
        'packages'   => t('a_packages'),
        'features'   => t('a_features'),
        'addons'     => t('a_addons'),
        'inquiries'  => t('a_inquiries'),
        'settings'   => t('a_settings'),
      ];
      foreach ($links as $path => $label): ?>
        <a class="admin__link <?= $here === $path ? 'admin__link--on' : '' ?>"
           href="<?= e(admin_url($path)) ?>"
           <?= $here === $path ? 'aria-current="page"' : '' ?>><?= e($label) ?></a>
      <?php endforeach; ?>
      <a class="admin__link" href="<?= e(url('/')) ?>"><?= e(t('a_view_site')) ?></a>
      <form class="inline-form" method="post" action="<?= e(admin_url('logout')) ?>">
        <?= csrf_field() ?>
        <button class="admin__link" type="submit"
                style="background:none;border:0;cursor:pointer;font-family:var(--sans)">
          <?= e(t('logout')) ?>
        </button>
      </form>
    </nav>
  </div>
</header>

<main class="admin__main" id="admin-main">
  <div class="shell">
    <?php foreach (flash_take() as $msg): ?>
      <div class="notice notice--<?= e($msg['type']) ?>"><?= e($msg['message']) ?></div>
    <?php endforeach; ?>
