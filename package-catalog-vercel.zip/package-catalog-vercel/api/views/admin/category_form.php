<?php
/** @var array|null $category @var array $errors */
$isEdit = $category !== null;
$adminTitle = $isEdit ? t('a_edit') : t('a_new'); $here = 'categories';
$val = function (string $k, string $d = '') use ($category) {
    $o = old($k); return $o !== '' ? $o : (string) ($category[$k] ?? $d);
};
require __DIR__ . '/head.php';
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e($adminTitle) ?> — <?= e(t('a_categories')) ?></h1>
  <a class="btn btn--ghost btn--sm btn--auto" href="<?= e(admin_url('categories')) ?>"><?= e(t('a_cancel')) ?></a>
</div>

<form class="panel" method="post" action="<?= e(admin_url('categories/save')) ?>"
      novalidate>
  <?= csrf_field() ?>
  <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= (int) $category['id'] ?>"><?php endif; ?>

  <div class="grid-2">
    <div class="field">
      <label class="field__label" for="name_en"><?= e(t('a_name')) ?> — <?= e(t('a_english')) ?> <span class="field__req">*</span></label>
      <input class="input <?= isset($errors['name_en']) ? 'input--error' : '' ?>" id="name_en" name="name_en" required maxlength="120" value="<?= e($val('name_en')) ?>">
      <?php if (isset($errors['name_en'])): ?><span class="field__error"><?= e($errors['name_en']) ?></span><?php endif; ?>
    </div>
    <div class="field">
      <label class="field__label" for="name_am"><?= e(t('a_name')) ?> — <?= e(t('a_amharic')) ?> <span class="field__req">*</span></label>
      <input class="input <?= isset($errors['name_am']) ? 'input--error' : '' ?>" id="name_am" name="name_am" required maxlength="120" lang="am" value="<?= e($val('name_am')) ?>">
      <?php if (isset($errors['name_am'])): ?><span class="field__error"><?= e($errors['name_am']) ?></span><?php endif; ?>
    </div>
    <div class="field">
      <label class="field__label" for="tagline_en"><?= e(t('a_tagline')) ?> — <?= e(t('a_english')) ?></label>
      <input class="input" id="tagline_en" name="tagline_en" maxlength="200" value="<?= e($val('tagline_en')) ?>">
    </div>
    <div class="field">
      <label class="field__label" for="tagline_am"><?= e(t('a_tagline')) ?> — <?= e(t('a_amharic')) ?></label>
      <input class="input" id="tagline_am" name="tagline_am" maxlength="200" lang="am" value="<?= e($val('tagline_am')) ?>">
    </div>
    <div class="field">
      <label class="field__label" for="description_en"><?= e(t('a_description')) ?> — <?= e(t('a_english')) ?></label>
      <textarea class="textarea" id="description_en" name="description_en" maxlength="5000"><?= e($val('description_en')) ?></textarea>
    </div>
    <div class="field">
      <label class="field__label" for="description_am"><?= e(t('a_description')) ?> — <?= e(t('a_amharic')) ?></label>
      <textarea class="textarea" id="description_am" name="description_am" maxlength="5000" lang="am"><?= e($val('description_am')) ?></textarea>
    </div>
  </div>

  <div class="grid-2" style="margin-top:1.15rem">
    <div class="field">
      <label class="field__label" for="slug"><?= e(t('a_slug')) ?></label>
      <input class="input" id="slug" name="slug" maxlength="80" value="<?= e($val('slug')) ?>" placeholder="real-estate">
      <span class="field__hint">Leave blank to generate from the English name.</span>
    </div>
    <div class="field">
      <label class="field__label" for="sort_order"><?= e(t('a_order')) ?></label>
      <input class="input" type="number" id="sort_order" name="sort_order" value="<?= e($val('sort_order', '0')) ?>">
    </div>
  </div>

  <label class="check" style="margin-top:1rem">
    <input type="checkbox" name="is_active" value="1" <?= (!$isEdit || (int) $category['is_active']) ? 'checked' : '' ?>>
    <?= e(t('a_active')) ?>
  </label>

  <div class="form__actions">
    <button class="btn btn--primary btn--auto" type="submit"><?= e(t('a_save')) ?></button>
    <a class="btn btn--ghost btn--auto" href="<?= e(admin_url('categories')) ?>"><?= e(t('a_cancel')) ?></a>
  </div>
</form>
<?php clear_old(); require __DIR__ . '/foot.php'; ?>
