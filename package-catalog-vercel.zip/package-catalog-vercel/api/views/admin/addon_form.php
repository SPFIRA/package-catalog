<?php
/** @var array|null $addon @var array $categories @var array $errors */
$isEdit = $addon !== null;
$adminTitle = $isEdit ? t('a_edit') : t('a_new'); $here = 'addons';
$val = function (string $k, string $d = '') use ($addon) {
    $o = old($k); return $o !== '' ? $o : (string) ($addon[$k] ?? $d);
};
require __DIR__ . '/head.php';
?>
<div class="admin__head">
  <h1 class="admin__title"><?= e($adminTitle) ?> — <?= e(t('a_addons')) ?></h1>
  <a class="btn btn--ghost btn--sm btn--auto" href="<?= e(admin_url('addons')) ?>"><?= e(t('a_cancel')) ?></a>
</div>

<form class="panel" method="post" action="<?= e(admin_url('addons/save')) ?>" novalidate>
  <?= csrf_field() ?>
  <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= (int) $addon['id'] ?>"><?php endif; ?>

  <div class="grid-2">
    <div class="field">
      <label class="field__label" for="name_en"><?= e(t('a_name')) ?> — <?= e(t('a_english')) ?> <span class="field__req">*</span></label>
      <input class="input <?= isset($errors['name_en']) ? 'input--error' : '' ?>" id="name_en" name="name_en" required maxlength="140" value="<?= e($val('name_en')) ?>">
      <?php if (isset($errors['name_en'])): ?><span class="field__error"><?= e($errors['name_en']) ?></span><?php endif; ?>
    </div>
    <div class="field">
      <label class="field__label" for="name_am"><?= e(t('a_name')) ?> — <?= e(t('a_amharic')) ?> <span class="field__req">*</span></label>
      <input class="input <?= isset($errors['name_am']) ? 'input--error' : '' ?>" id="name_am" name="name_am" required maxlength="140" lang="am" value="<?= e($val('name_am')) ?>">
      <?php if (isset($errors['name_am'])): ?><span class="field__error"><?= e($errors['name_am']) ?></span><?php endif; ?>
    </div>
    <div class="field">
      <label class="field__label" for="description_en"><?= e(t('a_description')) ?> — <?= e(t('a_english')) ?></label>
      <textarea class="textarea" id="description_en" name="description_en" maxlength="400"><?= e($val('description_en')) ?></textarea>
    </div>
    <div class="field">
      <label class="field__label" for="description_am"><?= e(t('a_description')) ?> — <?= e(t('a_amharic')) ?></label>
      <textarea class="textarea" id="description_am" name="description_am" maxlength="400" lang="am"><?= e($val('description_am')) ?></textarea>
    </div>
  </div>

  <div class="grid-3" style="margin-top:1.15rem">
    <div class="field">
      <label class="field__label" for="price"><?= e(t('a_price')) ?> <span class="field__req">*</span></label>
      <input class="input <?= isset($errors['price']) ? 'input--error' : '' ?>" type="number" step="0.01" min="0" id="price" name="price" required value="<?= e($val('price', '0')) ?>">
    </div>
    <div class="field">
      <label class="field__label" for="currency"><?= e(t('a_currency')) ?> <span class="field__req">*</span></label>
      <input class="input" id="currency" name="currency" required maxlength="8" value="<?= e($val('currency', 'ETB')) ?>">
    </div>
    <div class="field">
      <label class="field__label" for="billing_cycle"><?= e(t('a_billing')) ?> <span class="field__req">*</span></label>
      <select class="select" id="billing_cycle" name="billing_cycle" required>
        <?php foreach (['one_time', 'monthly', 'yearly'] as $cycle): ?>
          <option value="<?= e($cycle) ?>" <?= $val('billing_cycle', 'one_time') === $cycle ? 'selected' : '' ?>><?= e(t('billing_' . $cycle)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="field">
      <label class="field__label" for="category_id"><?= e(t('a_category')) ?></label>
      <select class="select" id="category_id" name="category_id">
        <option value=""><?= e(t('a_all')) ?></option>
        <?php foreach ($categories as $c): ?>
          <option value="<?= (int) $c['id'] ?>" <?= $val('category_id') === (string) $c['id'] ? 'selected' : '' ?>><?= e($c['name_en']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="field">
      <label class="field__label" for="sort_order"><?= e(t('a_order')) ?></label>
      <input class="input" type="number" id="sort_order" name="sort_order" value="<?= e($val('sort_order', '0')) ?>">
    </div>
  </div>

  <label class="check" style="margin-top:1rem">
    <input type="checkbox" name="is_active" value="1" <?= (!$isEdit || (int) $addon['is_active']) ? 'checked' : '' ?>>
    <?= e(t('a_active')) ?>
  </label>

  <div class="form__actions">
    <button class="btn btn--primary btn--auto" type="submit"><?= e(t('a_save')) ?></button>
    <a class="btn btn--ghost btn--auto" href="<?= e(admin_url('addons')) ?>"><?= e(t('a_cancel')) ?></a>
  </div>
</form>
<?php clear_old(); require __DIR__ . '/foot.php'; ?>
