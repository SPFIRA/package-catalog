<?php
/**
 * @var array $category
 * @var array $packages
 * @var array $features
 * @var array $matrix     [package_id][feature_id] => row
 * @var array $addons
 * @var array $grouped
 * @var array $errors
 */
$title           = tr($category, 'name');
$metaDescription = tr($category, 'tagline');
require __DIR__ . '/partials/head.php';
?>

<section class="hero">
  <div class="shell">
    <p class="crumb" style="color:#A9BFB2">
      <a href="<?= e(url('/')) ?>" style="color:#A9BFB2"><?= e(t('back_to_all')) ?></a>
      <span aria-hidden="true">&nbsp;/&nbsp;</span> <?= e(tr($category, 'name')) ?>
    </p>
    <h1 class="hero__title display"><?= e(tr($category, 'name')) ?></h1>
    <p class="hero__sub"><?= e(tr($category, 'description') ?: tr($category, 'tagline')) ?></p>
  </div>
</section>

<section class="band">
  <div class="shell">
    <?php if (!$packages): ?>
      <div class="empty"><?= e(t('no_packages')) ?></div>
    <?php else: ?>

      <div class="sheets">
        <?php foreach ($packages as $p): ?>
          <?php $featured = (int) $p['is_featured'] === 1; ?>
          <article class="sheet <?= $featured ? 'sheet--featured' : '' ?>">
            <?php if ($featured): ?>
              <span class="sheet__flag"><?= e(t('most_chosen')) ?></span>
            <?php endif; ?>

            <header class="sheet__head">
              <p class="sheet__ref"><?= e(t('ref')) ?> <?= e(package_ref($category, $p)) ?></p>
              <h2 class="sheet__name"><?= e(tr($p, 'name')) ?></h2>
              <p class="sheet__tag"><?= e(tr($p, 'tagline')) ?></p>
            </header>

            <div class="sheet__price">
              <div class="sheet__amount"><?= e(money((float) $p['price'], $p['currency'])) ?></div>
              <?php if (tr($p, 'price_note')): ?>
                <div class="sheet__note"><?= e(tr($p, 'price_note')) ?></div>
              <?php endif; ?>
            </div>

            <div class="sheet__body">
              <?php if (tr($p, 'summary')): ?>
                <p class="sheet__summary"><?= e(tr($p, 'summary')) ?></p>
              <?php endif; ?>

              <?php if ($p['delivery_days']): ?>
                <p class="spec">
                  <span class="spec__k"><?= e(t('delivery')) ?></span>
                  <span class="spec__dots" aria-hidden="true"></span>
                  <span class="spec__v"><?= e(t('days', ['n' => (int) $p['delivery_days']])) ?></span>
                </p>
              <?php endif; ?>
              <?php if ($p['revision_rounds']): ?>
                <p class="spec">
                  <span class="spec__k"><?= e(t('revisions')) ?></span>
                  <span class="spec__dots" aria-hidden="true"></span>
                  <span class="spec__v"><?= (int) $p['revision_rounds'] ?></span>
                </p>
              <?php endif; ?>
              <?php if ($p['support_months']): ?>
                <p class="spec">
                  <span class="spec__k"><?= e(t('support')) ?></span>
                  <span class="spec__dots" aria-hidden="true"></span>
                  <span class="spec__v">
                    <?= (int) $p['support_months'] === 1
                        ? e(t('month'))
                        : e(t('months', ['n' => (int) $p['support_months']])) ?>
                  </span>
                </p>
              <?php endif; ?>
            </div>

            <footer class="sheet__foot">
              <a class="btn <?= $featured ? 'btn--accent' : 'btn--primary' ?>"
                 href="<?= e(url('/p/' . $category['slug'] . '/' . $p['slug'])) ?>">
                <?= e(t('choose_package')) ?>
              </a>
            </footer>
          </article>
        <?php endforeach; ?>
      </div>

      <?php if ($features): ?>
        <div class="band__head" style="margin-top:3.5rem">
          <h2 class="band__title display"><?= e(t('compare_heading')) ?></h2>
        </div>

        <div class="compare-wrap">
          <table class="compare">
            <caption class="sr-only"><?= e(t('compare_heading')) ?></caption>
            <thead>
              <tr>
                <th scope="col"><?= e(t('feature')) ?></th>
                <?php foreach ($packages as $p): ?>
                  <th scope="col" style="text-align:center"><?= e(tr($p, 'name')) ?></th>
                <?php endforeach; ?>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($features as $f): ?>
                <tr>
                  <th scope="row" class="compare__feature"><?= e(tr($f, 'label')) ?></th>
                  <?php foreach ($packages as $p): ?>
                    <?php
                      $cell     = $matrix[$p['id']][$f['id']] ?? null;
                      $included = $cell && (int) $cell['is_included'] === 1;
                      $value    = $cell ? tr($cell, 'value') : '';
                    ?>
                    <td class="compare__cell">
                      <?php if ($value !== ''): ?>
                        <?php if (!$included): ?>
                          <span class="mark mark--no" aria-hidden="true">–</span><br>
                        <?php endif; ?>
                        <?= e($value) ?>
                      <?php elseif ($included): ?>
                        <span class="mark mark--yes" aria-hidden="true">✓</span>
                        <span class="sr-only"><?= e(t('included')) ?></span>
                      <?php else: ?>
                        <span class="mark mark--no" aria-hidden="true">–</span>
                        <span class="sr-only"><?= e(t('not_included')) ?></span>
                      <?php endif; ?>
                    </td>
                  <?php endforeach; ?>
                </tr>
              <?php endforeach; ?>
              <tr class="compare__price">
                <th scope="row" class="compare__feature"><?= e(t('a_price')) ?></th>
                <?php foreach ($packages as $p): ?>
                  <td class="compare__cell"><?= e(money((float) $p['price'], $p['currency'])) ?></td>
                <?php endforeach; ?>
              </tr>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

    <?php endif; ?>
  </div>
</section>

<?php if ($addons): ?>
<section class="band band--surface">
  <div class="shell">
    <div class="band__head">
      <p class="eyebrow eyebrow--stone"><?= e(t('addons_heading')) ?></p>
      <h2 class="band__title display"><?= e(t('addons_intro')) ?></h2>
    </div>
    <div class="addons">
      <?php foreach ($addons as $a): ?>
        <article class="addon">
          <h3 class="addon__name"><?= e(tr($a, 'name')) ?></h3>
          <p class="addon__desc"><?= e(tr($a, 'description')) ?></p>
          <p class="addon__price">
            <?= e(money((float) $a['price'], $a['currency'])) ?>
            <span class="addon__cycle"><?= e(t('billing_' . $a['billing_cycle'])) ?></span>
          </p>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php
require __DIR__ . '/partials/enquiry_form.php';
require __DIR__ . '/partials/foot.php';
