<?php
$title = t('thanks_heading');
require __DIR__ . '/partials/head.php';
?>
<section class="band">
  <div class="shell" style="max-width:640px">
    <div class="panel" style="border-top:4px solid var(--ok)">
      <p class="eyebrow"><?= e(setting('site_name')) ?></p>
      <h1 class="band__title display"><?= e(t('thanks_heading')) ?></h1>
      <p><?= e(t('thanks_body')) ?></p>
      <?php if (setting('phone')): ?>
        <p class="spec">
          <span class="spec__k"><?= e(t('a_phone')) ?></span>
          <span class="spec__dots" aria-hidden="true"></span>
          <span class="spec__v"><?= e(setting('phone')) ?></span>
        </p>
      <?php endif; ?>
      <p style="margin-top:1.5rem">
        <a class="btn btn--primary btn--auto" href="<?= e(url('/')) ?>"><?= e(t('thanks_back')) ?></a>
      </p>
    </div>
  </div>
</section>
<?php require __DIR__ . '/partials/foot.php'; ?>
