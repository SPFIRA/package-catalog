<?php
/**
 * @var array $categories  each with _count and _min_price
 * @var array $grouped
 * @var array $errors
 * @var int   $totalPackages
 */
$title = t('nav_packages');
require __DIR__ . '/partials/head.php';
?>

<section class="hero">
  <div class="shell hero__grid">
    <div>
      <p class="eyebrow"><?= e(setting('tagline')) ?></p>
      <h1 class="hero__title display"><?= e(setting('hero_line')) ?></h1>
      <p class="hero__sub"><?= e(setting('hero_sub')) ?></p>
    </div>
    <div class="hero__meta">
      <div class="hero__stat">
        <span class="hero__stat-k"><?= e((string) count($categories)) ?></span>
        <span class="hero__stat-v"><?= e(t('a_categories')) ?></span>
      </div>
      <div class="hero__stat">
        <span class="hero__stat-k"><?= e((string) $totalPackages) ?></span>
        <span class="hero__stat-v"><?= e(t('nav_packages')) ?></span>
      </div>
      <div class="hero__stat">
        <span class="hero__stat-k">14</span>
        <span class="hero__stat-v"><?= e(t('days', ['n' => ''])) ?></span>
      </div>
    </div>
  </div>
</section>

<section class="band">
  <div class="shell">
    <div class="band__head">
      <p class="band__lede"><?= e(t('home_intro')) ?></p>
    </div>

    <?php if (!$categories): ?>
      <div class="empty"><?= e(t('no_categories')) ?></div>
    <?php else: ?>
      <div class="cats">
        <?php foreach ($categories as $cat): ?>
          <a class="cat" href="<?= e(url('/c/' . $cat['slug'])) ?>">
            <h2 class="cat__name"><?= e(tr($cat, 'name')) ?></h2>
            <p class="cat__tag"><?= e(tr($cat, 'tagline')) ?></p>
            <span class="cat__foot">
              <span class="cat__from">
                <?php if ($cat['_min_price'] !== null): ?>
                  <?= e(t('from_price', ['price' => money((float) $cat['_min_price'])])) ?>
                <?php else: ?>
                  &mdash;
                <?php endif; ?>
              </span>
              <span class="cat__go"><?= e(t('view_packages')) ?> &rarr;</span>
            </span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php
require __DIR__ . '/partials/enquiry_form.php';
require __DIR__ . '/partials/foot.php';
