<?php
/**
 * Admin controller.
 *
 * Every route except login/logout calls require_auth() first, and every
 * state-changing route is POST + csrf_check(). There is no route here
 * that mutates data on a GET request.
 */
declare(strict_types=1);

function admin_route(array $seg, string $method): void
{
    $action = $seg[0] ?? '';

    // ---------------- login / logout ----------------
    if ($action === 'login') {
        if (auth_check()) {
            redirect(admin_url(''));
        }
        if ($method === 'POST') {
            csrf_check();
            $v = validate($_POST, [
                'email'    => 'required|email|max:190',
                'password' => 'required|max:200',
            ]);
            if ($v['errors']) {
                admin_view('admin/login', ['error' => t('login_failed')]);
                return;
            }
            $error = auth_attempt($v['data']['email'], (string) $_POST['password']);
            if ($error !== null) {
                admin_view('admin/login', ['error' => $error]);
                return;
            }
            $intended = $_SESSION['intended'] ?? admin_url('');
            unset($_SESSION['intended']);
            redirect(is_string($intended) ? $intended : admin_url(''));
        }
        admin_view('admin/login', ['error' => null]);
        return;
    }

    if ($action === 'logout') {
        if ($method === 'POST') {
            csrf_check();
            auth_logout();
        }
        redirect(admin_url('login'));
    }

    // ---------------- everything below requires a session ----------------
    $user = require_auth();

    switch ($action) {

        // ================= dashboard =================
        case '':
            admin_view('admin/dashboard', [
                'user'    => $user,
                'stats'   => admin_stats(),
                'recent'  => array_slice(admin_inquiries(), 0, 8),
            ]);
            return;

        // ================= categories =================
        case 'categories':
            $sub = $seg[1] ?? '';

            if ($sub === 'save' && $method === 'POST') {
                csrf_check();
                admin_save_category();
            }
            if ($sub === 'delete' && $method === 'POST') {
                csrf_check();
                $id = (int) ($_POST['id'] ?? 0);
                if (admin_category($id)) {
                    q('DELETE FROM categories WHERE id = ?', [$id]);
                    flash('ok', t('a_deleted'));
                }
                redirect(admin_url('categories'));
            }
            if ($sub === 'new' || $sub === 'edit') {
                $cat = $sub === 'edit' ? admin_category((int) ($seg[2] ?? 0)) : null;
                if ($sub === 'edit' && !$cat) {
                    show_error(404);
                }
                admin_view('admin/category_form', [
                    'user'     => $user,
                    'category' => $cat,
                    'errors'   => errors_take(),
                ]);
                return;
            }
            admin_view('admin/categories', ['user' => $user, 'rows' => admin_categories()]);
            return;

        // ================= packages =================
        case 'packages':
            $sub = $seg[1] ?? '';

            if ($sub === 'save' && $method === 'POST') {
                csrf_check();
                admin_save_package();
            }
            if ($sub === 'delete' && $method === 'POST') {
                csrf_check();
                $id = (int) ($_POST['id'] ?? 0);
                // Soft delete: keeps historical enquiries readable.
                q('UPDATE packages SET deleted_at = NOW(), is_active = 0 WHERE id = ?', [$id]);
                flash('ok', t('a_deleted'));
                redirect(admin_url('packages'));
            }
            if ($sub === 'new' || $sub === 'edit') {
                $pkg = $sub === 'edit' ? admin_package((int) ($seg[2] ?? 0)) : null;
                if ($sub === 'edit' && !$pkg) {
                    show_error(404);
                }
                $catId = $pkg
                    ? (int) $pkg['category_id']
                    : (int) ($_GET['category'] ?? 0);

                admin_view('admin/package_form', [
                    'user'       => $user,
                    'package'    => $pkg,
                    'categories' => admin_categories(),
                    'features'   => $catId ? category_features($catId) : [],
                    'assigned'   => $pkg ? feature_matrix([(int) $pkg['id']])[(int) $pkg['id']] ?? [] : [],
                    'catId'      => $catId,
                    'errors'     => errors_take(),
                ]);
                return;
            }
            $filter = (int) ($_GET['category'] ?? 0);
            admin_view('admin/packages', [
                'user'       => $user,
                'rows'       => admin_packages($filter ?: null),
                'categories' => admin_categories(),
                'filter'     => $filter,
            ]);
            return;

        // ================= features =================
        case 'features':
            $sub = $seg[1] ?? '';

            if ($sub === 'save' && $method === 'POST') {
                csrf_check();
                admin_save_feature();
            }
            if ($sub === 'save_all' && $method === 'POST') {
                csrf_check();
                admin_save_features_bulk();
            }
            if ($sub === 'delete' && $method === 'POST') {
                csrf_check();
                q('DELETE FROM features WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
                flash('ok', t('a_deleted'));
                redirect(admin_url('features?category=' . (int) ($_POST['category_id'] ?? 0)));
            }
            $catId = (int) ($_GET['category'] ?? 0);
            $cats  = admin_categories();
            if (!$catId && $cats) {
                $catId = (int) $cats[0]['id'];
            }
            admin_view('admin/features', [
                'user'       => $user,
                'categories' => $cats,
                'catId'      => $catId,
                'rows'       => $catId ? category_features($catId) : [],
                'errors'     => errors_take(),
            ]);
            return;

        // ================= add-ons =================
        case 'addons':
            $sub = $seg[1] ?? '';

            if ($sub === 'save' && $method === 'POST') {
                csrf_check();
                admin_save_addon();
            }
            if ($sub === 'delete' && $method === 'POST') {
                csrf_check();
                q('DELETE FROM addons WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
                flash('ok', t('a_deleted'));
                redirect(admin_url('addons'));
            }
            if ($sub === 'new' || $sub === 'edit') {
                $addon = $sub === 'edit' ? admin_addon((int) ($seg[2] ?? 0)) : null;
                if ($sub === 'edit' && !$addon) {
                    show_error(404);
                }
                admin_view('admin/addon_form', [
                    'user'       => $user,
                    'addon'      => $addon,
                    'categories' => admin_categories(),
                    'errors'     => errors_take(),
                ]);
                return;
            }
            admin_view('admin/addons', ['user' => $user, 'rows' => admin_addons()]);
            return;

        // ================= enquiries =================
        case 'inquiries':
            $sub = $seg[1] ?? '';

            if ($sub === 'update' && $method === 'POST') {
                csrf_check();
                $v = validate($_POST, [
                    'id'         => 'required|int',
                    'status'     => 'required|in:new,contacted,quoted,won,lost',
                    'admin_note' => 'nullable|max:4000',
                ]);
                if (!$v['errors']) {
                    q('UPDATE inquiries SET status = ?, admin_note = ? WHERE id = ?', [
                        $v['data']['status'],
                        $v['data']['admin_note'] ?: null,
                        (int) $v['data']['id'],
                    ]);
                    flash('ok', t('a_saved'));
                }
                redirect(admin_url('inquiries/show/' . (int) ($_POST['id'] ?? 0)));
            }
            if ($sub === 'delete' && $method === 'POST') {
                csrf_check();
                q('DELETE FROM inquiries WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
                flash('ok', t('a_deleted'));
                redirect(admin_url('inquiries'));
            }
            if ($sub === 'show') {
                $row = admin_inquiry((int) ($seg[2] ?? 0));
                if (!$row) {
                    show_error(404);
                }
                admin_view('admin/inquiry_show', ['user' => $user, 'row' => $row]);
                return;
            }
            $status = (string) ($_GET['status'] ?? '');
            admin_view('admin/inquiries', [
                'user'   => $user,
                'rows'   => admin_inquiries($status),
                'status' => $status,
            ]);
            return;

        // ================= settings =================
        case 'settings':
            if (($seg[1] ?? '') === 'save' && $method === 'POST') {
                csrf_check();
                foreach ((array) ($_POST['s'] ?? []) as $key => $pair) {
                    $key = substr(preg_replace('/[^a-z0-9_]/', '', (string) $key), 0, 80);
                    if ($key === '') {
                        continue;
                    }
                    q(
                        'INSERT INTO settings ("key", value_en, value_am) VALUES (?,?,?)
                         ON CONFLICT ("key") DO UPDATE
                            SET value_en = EXCLUDED.value_en, value_am = EXCLUDED.value_am',
                        [
                            $key,
                            mb_substr(trim((string) ($pair['en'] ?? '')), 0, 5000),
                            mb_substr(trim((string) ($pair['am'] ?? '')), 0, 5000),
                        ]
                    );
                }
                flash('ok', t('a_saved'));
                redirect(admin_url('settings'));
            }
            admin_view('admin/settings', [
                'user' => $user,
                'rows' => q_all('SELECT * FROM settings ORDER BY "key"'),
            ]);
            return;

        default:
            show_error(404);
    }
}

/** Render an admin view. */
function admin_view(string $name, array $data = []): void
{
    view($name, $data);
}

// ---------------------------------------------------------------
// Write handlers
// ---------------------------------------------------------------

function admin_save_category(): never
{
    $id = (int) ($_POST['id'] ?? 0);

    $v = validate($_POST, [
        'name_en'        => 'required|max:120',
        'name_am'        => 'required|max:120',
        'slug'           => 'nullable|max:80',
        'tagline_en'     => 'nullable|max:200',
        'tagline_am'     => 'nullable|max:200',
        'description_en' => 'nullable|max:5000',
        'description_am' => 'nullable|max:5000',
        'sort_order'     => 'nullable|int',
        'is_active'      => 'nullable|boolean',
    ]);

    if ($v['errors']) {
        remember_input($_POST);
        remember_errors($v['errors']);
        redirect($id ? admin_url('categories/edit/' . $id) : admin_url('categories/new'));
    }

    $d    = $v['data'];
    $slug = unique_slug('categories', slugify($d['slug'] ?: $d['name_en']), null, $id);

    $params = [
        $slug, $d['name_en'], $d['name_am'],
        $d['tagline_en'], $d['tagline_am'],
        $d['description_en'], $d['description_am'],
        (int) ($d['sort_order'] ?? 0), (int) ($d['is_active'] ?? 0),
    ];

    if ($id) {
        if (!admin_category($id)) {
            show_error(404);
        }
        $params[] = $id;
        q('UPDATE categories SET slug=?, name_en=?, name_am=?, tagline_en=?, tagline_am=?,
              description_en=?, description_am=?, sort_order=?, is_active=?
           WHERE id=?', $params);
    } else {
        q('INSERT INTO categories
             (slug, name_en, name_am, tagline_en, tagline_am,
              description_en, description_am, sort_order, is_active)
           VALUES (?,?,?,?,?,?,?,?,?)', $params);
    }

    clear_old();
    flash('ok', t('a_saved'));
    redirect(admin_url('categories'));
}

function admin_save_package(): never
{
    $id = (int) ($_POST['id'] ?? 0);

    $v = validate($_POST, [
        'category_id'     => 'required|int',
        'name_en'         => 'required|max:120',
        'name_am'         => 'required|max:120',
        'slug'            => 'nullable|max:80',
        'tagline_en'      => 'nullable|max:200',
        'tagline_am'      => 'nullable|max:200',
        'summary_en'      => 'nullable|max:2000',
        'summary_am'      => 'nullable|max:2000',
        'description_en'  => 'nullable|max:20000',
        'description_am'  => 'nullable|max:20000',
        'price'           => 'required|numeric|min:0|max:99999999',
        'currency'        => 'required|max:8',
        'price_note_en'   => 'nullable|max:120',
        'price_note_am'   => 'nullable|max:120',
        'delivery_days'   => 'nullable|int|min:0|max:3650',
        'revision_rounds' => 'nullable|int|min:0|max:99',
        'support_months'  => 'nullable|int|min:0|max:99',
        'sort_order'      => 'nullable|int',
        'is_featured'     => 'nullable|boolean',
        'is_active'       => 'nullable|boolean',
    ]);

    $backTo = $id ? admin_url('packages/edit/' . $id) : admin_url('packages/new');

    if ($v['errors']) {
        remember_input($_POST);
        remember_errors($v['errors']);
        redirect($backTo);
    }

    $d = $v['data'];

    if (!admin_category((int) $d['category_id'])) {
        remember_errors(['category_id' => t('v_invalid')]);
        redirect($backTo);
    }

    $slug = unique_slug('packages', slugify($d['slug'] ?: $d['name_en']), (int) $d['category_id'], $id);

    $params = [
        (int) $d['category_id'], $slug, $d['name_en'], $d['name_am'],
        $d['tagline_en'], $d['tagline_am'], $d['summary_en'], $d['summary_am'],
        $d['description_en'], $d['description_am'],
        (float) $d['price'], $d['currency'], $d['price_note_en'], $d['price_note_am'],
        $d['delivery_days'] !== null ? (int) $d['delivery_days'] : null,
        $d['revision_rounds'] !== null ? (int) $d['revision_rounds'] : null,
        $d['support_months'] !== null ? (int) $d['support_months'] : null,
        (int) ($d['is_featured'] ?? 0), (int) ($d['sort_order'] ?? 0), (int) ($d['is_active'] ?? 0),
    ];

    if ($id) {
        $params[] = $id;
        q('UPDATE packages SET category_id=?, slug=?, name_en=?, name_am=?, tagline_en=?, tagline_am=?,
              summary_en=?, summary_am=?, description_en=?, description_am=?, price=?, currency=?,
              price_note_en=?, price_note_am=?, delivery_days=?, revision_rounds=?, support_months=?,
              is_featured=?, sort_order=?, is_active=?
           WHERE id=? AND deleted_at IS NULL', $params);
        $packageId = $id;
    } else {
        $packageId = q_insert_id('INSERT INTO packages
             (category_id, slug, name_en, name_am, tagline_en, tagline_am, summary_en, summary_am,
              description_en, description_am, price, currency, price_note_en, price_note_am,
              delivery_days, revision_rounds, support_months, is_featured, sort_order, is_active)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', $params);
    }

    // ---- feature matrix ----
    // Rewrite the pivot for this package only. Feature ids are checked
    // against the package's own category so a tampered form cannot attach
    // a feature belonging to somewhere else.
    $valid = array_column(category_features((int) $d['category_id']), 'id');
    $valid = array_map('intval', $valid);

    q('DELETE FROM feature_package WHERE package_id = ?', [$packageId]);

    foreach ((array) ($_POST['feat'] ?? []) as $featureId => $row) {
        $featureId = (int) $featureId;
        if (!in_array($featureId, $valid, true)) {
            continue;
        }
        $included = !empty($row['on']) ? 1 : 0;
        $valEn    = mb_substr(trim((string) ($row['en'] ?? '')), 0, 120);
        $valAm    = mb_substr(trim((string) ($row['am'] ?? '')), 0, 120);

        if (!$included && $valEn === '' && $valAm === '') {
            continue;                       // nothing to store for this row
        }
        q('INSERT INTO feature_package (package_id, feature_id, is_included, value_en, value_am)
           VALUES (?,?,?,?,?)',
            [$packageId, $featureId, $included, $valEn ?: null, $valAm ?: null]);
    }

    clear_old();
    flash('ok', t('a_saved'));
    redirect(admin_url('packages/edit/' . $packageId));
}

function admin_save_feature(): never
{
    $id = (int) ($_POST['id'] ?? 0);

    $v = validate($_POST, [
        'category_id' => 'required|int',
        'label_en'    => 'required|max:180',
        'label_am'    => 'required|max:180',
        'sort_order'  => 'nullable|int',
    ]);

    $back = admin_url('features?category=' . (int) ($_POST['category_id'] ?? 0));

    if ($v['errors']) {
        remember_input($_POST);
        remember_errors($v['errors']);
        redirect($back);
    }

    $d = $v['data'];
    if (!admin_category((int) $d['category_id'])) {
        redirect($back);
    }

    if ($id) {
        q('UPDATE features SET label_en=?, label_am=?, sort_order=? WHERE id=? AND category_id=?',
            [$d['label_en'], $d['label_am'], (int) ($d['sort_order'] ?? 0), $id, (int) $d['category_id']]);
    } else {
        q('INSERT INTO features (category_id, label_en, label_am, sort_order) VALUES (?,?,?,?)',
            [(int) $d['category_id'], $d['label_en'], $d['label_am'], (int) ($d['sort_order'] ?? 0)]);
    }

    clear_old();
    flash('ok', t('a_saved'));
    redirect($back);
}

/**
 * Update every feature row for one category in a single submit.
 * Each id is checked against the posted category so a tampered form
 * cannot rename a feature belonging to a different category.
 */
function admin_save_features_bulk(): never
{
    $catId = (int) ($_POST['category_id'] ?? 0);
    $back  = admin_url('features?category=' . $catId);

    if (!$catId || !admin_category($catId)) {
        redirect(admin_url('features'));
    }

    $owned = array_map('intval', array_column(category_features($catId), 'id'));

    foreach ((array) ($_POST['f'] ?? []) as $id => $row) {
        $id = (int) $id;
        if (!in_array($id, $owned, true)) {
            continue;
        }
        $labelEn = mb_substr(trim((string) ($row['label_en'] ?? '')), 0, 180);
        $labelAm = mb_substr(trim((string) ($row['label_am'] ?? '')), 0, 180);
        if ($labelEn === '' || $labelAm === '') {
            continue;                       // never blank out a live comparison row
        }
        q('UPDATE features SET label_en = ?, label_am = ?, sort_order = ?
           WHERE id = ? AND category_id = ?',
            [$labelEn, $labelAm, (int) ($row['sort_order'] ?? 0), $id, $catId]);
    }

    flash('ok', t('a_saved'));
    redirect($back);
}

function admin_save_addon(): never
{
    $id = (int) ($_POST['id'] ?? 0);

    $v = validate($_POST, [
        'category_id'    => 'nullable|int',
        'name_en'        => 'required|max:140',
        'name_am'        => 'required|max:140',
        'description_en' => 'nullable|max:400',
        'description_am' => 'nullable|max:400',
        'price'          => 'required|numeric|min:0|max:99999999',
        'currency'       => 'required|max:8',
        'billing_cycle'  => 'required|in:one_time,monthly,yearly',
        'sort_order'     => 'nullable|int',
        'is_active'      => 'nullable|boolean',
    ]);

    $back = $id ? admin_url('addons/edit/' . $id) : admin_url('addons/new');

    if ($v['errors']) {
        remember_input($_POST);
        remember_errors($v['errors']);
        redirect($back);
    }

    $d      = $v['data'];
    $catId  = !empty($d['category_id']) ? (int) $d['category_id'] : null;
    if ($catId !== null && !admin_category($catId)) {
        $catId = null;
    }

    $params = [
        $catId, $d['name_en'], $d['name_am'], $d['description_en'], $d['description_am'],
        (float) $d['price'], $d['currency'], $d['billing_cycle'],
        (int) ($d['sort_order'] ?? 0), (int) ($d['is_active'] ?? 0),
    ];

    if ($id) {
        $params[] = $id;
        q('UPDATE addons SET category_id=?, name_en=?, name_am=?, description_en=?, description_am=?,
              price=?, currency=?, billing_cycle=?, sort_order=?, is_active=? WHERE id=?', $params);
    } else {
        q('INSERT INTO addons
             (category_id, name_en, name_am, description_en, description_am,
              price, currency, billing_cycle, sort_order, is_active)
           VALUES (?,?,?,?,?,?,?,?,?,?)', $params);
    }

    clear_old();
    flash('ok', t('a_saved'));
    redirect(admin_url('addons'));
}
