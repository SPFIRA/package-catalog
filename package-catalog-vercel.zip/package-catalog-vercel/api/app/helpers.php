<?php
/**
 * Shared helpers: escaping, translation, URLs, flash messages.
 */
declare(strict_types=1);

// ---------------------------------------------------------------
// Errors
// ---------------------------------------------------------------

function log_error(string $message): void
{
    // No writable disk on Vercel. error_log() goes to stderr, which shows
    // up under the deployment's Runtime Logs.
    error_log('[package-catalog] ' . $message);
}

// ---------------------------------------------------------------
// Output escaping — every dynamic value passes through this
// ---------------------------------------------------------------

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// ---------------------------------------------------------------
// Language
// ---------------------------------------------------------------

function current_lang(): string
{
    static $lang = null;
    if ($lang !== null) {
        return $lang;
    }

    start_session();

    // ?lang=am switches and remembers.
    if (isset($_GET['lang']) && array_key_exists($_GET['lang'], LANGS)) {
        $_SESSION['lang'] = $_GET['lang'];
        setcookie('lang', $_GET['lang'], [
            'expires'  => time() + 31536000,
            'path'     => '/',
            'secure'   => is_https(),
            'httponly' => false,
            'samesite' => 'Lax',
        ]);
    }

    $lang = $_SESSION['lang']
        ?? (isset($_COOKIE['lang']) && array_key_exists($_COOKIE['lang'], LANGS) ? $_COOKIE['lang'] : null)
        ?? DEFAULT_LANG;

    if (!array_key_exists($lang, LANGS)) {
        $lang = DEFAULT_LANG;
    }

    $_SESSION['lang'] = $lang;
    return $lang;
}

/** Translate a UI string key from lang/{code}.php. */
function t(string $key, array $replace = []): string
{
    static $strings = [];
    $lang = current_lang();

    if (!isset($strings[$lang])) {
        $file = __DIR__ . '/../lang/' . $lang . '.php';
        $strings[$lang] = is_file($file) ? require $file : [];
    }

    $text = $strings[$lang][$key] ?? null;

    if ($text === null && $lang !== DEFAULT_LANG) {
        if (!isset($strings[DEFAULT_LANG])) {
            $file = __DIR__ . '/../lang/' . DEFAULT_LANG . '.php';
            $strings[DEFAULT_LANG] = is_file($file) ? require $file : [];
        }
        $text = $strings[DEFAULT_LANG][$key] ?? $key;
    }

    foreach ($replace as $k => $v) {
        $text = str_replace(':' . $k, (string) $v, (string) $text);
    }

    return (string) $text;
}

/**
 * Pick the right column from a bilingual database row.
 * tr($row, 'name') returns name_am when the site is in Amharic,
 * falling back to name_en when the Amharic value is empty.
 */
function tr(?array $row, string $field): string
{
    if (!$row) {
        return '';
    }
    $lang  = current_lang();
    $value = trim((string) ($row[$field . '_' . $lang] ?? ''));

    if ($value === '') {
        $value = trim((string) ($row[$field . '_' . DEFAULT_LANG] ?? ''));
    }
    return $value;
}

/** Language code for the <html lang> attribute. */
function html_lang(): string
{
    return current_lang() === 'am' ? 'am' : 'en';
}

/** Current URL with the lang swapped — for the language toggle. */
function lang_switch_url(string $to): string
{
    $query = $_GET;
    $query['lang'] = $to;
    $path = strtok((string) ($_SERVER['REQUEST_URI'] ?? '/'), '?');
    return $path . '?' . http_build_query($query);
}

// ---------------------------------------------------------------
// URLs
// ---------------------------------------------------------------

function url(string $path = ''): string
{
    return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
}

function admin_url(string $path = ''): string
{
    return url(ADMIN_PATH . '/' . ltrim($path, '/'));
}

function asset(string $path): string
{
    return url($path) . '?v=' . ASSET_VERSION;
}

function redirect(string $to): never
{
    header('Location: ' . $to, true, 302);
    exit;
}

// ---------------------------------------------------------------
// Flash messages and sticky form input
// ---------------------------------------------------------------

function flash(string $type, string $message): void
{
    start_session();
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flash_take(): array
{
    start_session();
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

/** Remember submitted values so a failed form does not lose the user's typing. */
function remember_input(array $input): void
{
    start_session();
    unset($input['_token'], $input['password']);
    $_SESSION['old'] = $input;
}

function old(string $key, string $default = ''): string
{
    start_session();
    return (string) ($_SESSION['old'][$key] ?? $default);
}

function clear_old(): void
{
    start_session();
    unset($_SESSION['old']);
}

function remember_errors(array $errors): void
{
    start_session();
    $_SESSION['errors'] = $errors;
}

function errors_take(): array
{
    start_session();
    $errors = $_SESSION['errors'] ?? [];
    unset($_SESSION['errors']);
    return $errors;
}

// ---------------------------------------------------------------
// Formatting
// ---------------------------------------------------------------

function money(float $amount, string $currency = 'ETB'): string
{
    return number_format($amount, 0, '.', ',') . ' ' . $currency;
}

function slugify(string $text): string
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text) ?? '';
    return trim($text, '-') ?: 'item';
}

/**
 * Human-quotable reference for a package, e.g. RE-PRO-1002.
 * Clients read this back over the phone, so it must stay stable —
 * it is derived from slugs and the row id, never from the price.
 */
function package_ref(array $category, array $package): string
{
    $cat = strtoupper(substr(preg_replace('/[^a-z0-9]/', '', $category['slug']) ?: 'XX', 0, 2));
    $pkg = strtoupper(substr(preg_replace('/[^a-z0-9]/', '', $package['slug']) ?: 'XXX', 0, 3));
    return $cat . '-' . $pkg . '-' . (int) $package['id'];
}

/** Read a setting in the current language. */
function setting(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (q_all('SELECT "key", value_en, value_am FROM settings') as $row) {
            $cache[$row['key']] = $row;
        }
    }
    if (!isset($cache[$key])) {
        return $default;
    }
    $value = tr($cache[$key], 'value');
    return $value !== '' ? $value : $default;
}

/** Render a view file with the given variables. */
function view(string $name, array $data = []): void
{
    extract($data, EXTR_SKIP);
    $file = __DIR__ . '/../views/' . $name . '.php';
    if (!is_file($file)) {
        log_error('Missing view: ' . $name);
        http_response_code(500);
        exit('Page unavailable.');
    }
    require $file;
}
