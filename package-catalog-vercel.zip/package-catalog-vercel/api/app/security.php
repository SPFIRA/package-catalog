<?php
/**
 * Security primitives: headers, session hardening, CSRF, rate limiting,
 * upload validation.
 */
declare(strict_types=1);

/** Send security headers. Called once, before any output. */
function send_security_headers(): void
{
    if (headers_sent()) {
        return;
    }
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    header('Cross-Origin-Opener-Policy: same-origin');

    // No CDN, no inline scripts, no inline styles: the policy can stay tight.
    header(
        "Content-Security-Policy: default-src 'self'; "
        . "img-src 'self' data:; "
        . "style-src 'self'; "
        . "script-src 'self'; "
        . "form-action 'self'; "
        . "frame-ancestors 'self'; "
        . "base-uri 'self'; "
        . "object-src 'none'"
    );

    if (is_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') {
        return true;
    }
    return (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
}

/** Start a hardened session. Safe to call more than once. */
function start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    // Sessions live in Postgres — see app/session.php for why.
    session_set_save_handler(new DatabaseSessionHandler(), true);

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('pcsid');
    session_start();

    // Idle timeout.
    $now = time();
    if (isset($_SESSION['last_seen']) && ($now - (int) $_SESSION['last_seen']) > SESSION_IDLE_TIMEOUT) {
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['last_seen'] = $now;
}

// ---------------------------------------------------------------
// CSRF
// ---------------------------------------------------------------

function csrf_token(): string
{
    start_session();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

/** Hidden input for forms. */
function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
}

/**
 * Verify the submitted token. Aborts with 419 on failure.
 * Uses hash_equals so the comparison is not timing-dependent.
 */
function csrf_check(): void
{
    start_session();
    $sent = (string) ($_POST['_token'] ?? '');
    $held = (string) ($_SESSION['csrf'] ?? '');

    if ($held === '' || $sent === '' || !hash_equals($held, $sent)) {
        http_response_code(419);
        exit('Your session expired. Go back, reload the page and try again.');
    }
}

// ---------------------------------------------------------------
// Rate limiting (database-backed, works on shared hosting)
// ---------------------------------------------------------------

function client_ip(): string
{
    // Do not trust proxy headers unless you control the proxy.
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return substr((string) $ip, 0, 45);
}

/**
 * Returns true if the caller is still within the limit, false if throttled.
 * Counts this call as one hit.
 */
function rate_limit_ok(string $bucket, int $max, int $windowSeconds): bool
{
    $ip  = client_ip();
    $now = date('Y-m-d H:i:s');
    $exp = date('Y-m-d H:i:s', time() + $windowSeconds);

    // Opportunistic cleanup of expired rows.
    q('DELETE FROM rate_limits WHERE expires_at < ?', [$now]);

    q(
        'INSERT INTO rate_limits (bucket, ip, hits, expires_at)
         VALUES (?, ?, 1, ?)
         ON CONFLICT (bucket, ip) DO UPDATE
            SET hits       = CASE WHEN rate_limits.expires_at < NOW()
                                  THEN 1 ELSE rate_limits.hits + 1 END,
                expires_at = CASE WHEN rate_limits.expires_at < NOW()
                                  THEN EXCLUDED.expires_at ELSE rate_limits.expires_at END',
        [$bucket, $ip, $exp]
    );

    $hits = (int) q_val(
        'SELECT hits FROM rate_limits WHERE bucket = ? AND ip = ?',
        [$bucket, $ip]
    );

    return $hits <= $max;
}

/** Clear a bucket, e.g. after a successful login. */
function rate_limit_clear(string $bucket): void
{
    q('DELETE FROM rate_limits WHERE bucket = ? AND ip = ?', [$bucket, client_ip()]);
}

// ---------------------------------------------------------------
// Uploads
// ---------------------------------------------------------------
// Deliberately absent. Vercel's filesystem is read-only apart from /tmp,
// which is wiped between invocations, so an uploaded file would appear to
// save and then vanish. The category cover-image field was removed rather
// than left as a feature that silently fails.
