<?php
/**
 * PDO connection to Postgres.
 *
 * Emulated prepares are off so placeholders are sent to the server
 * separately from the SQL text. That is what actually prevents SQL
 * injection — string escaping does not.
 */
declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    if (DATABASE_URL === '') {
        log_error('POSTGRES_URL is not set. Attach a Postgres database in the Vercel dashboard.');
        http_response_code(503);
        exit('The site is not configured yet.');
    }

    $parts = parse_url(DATABASE_URL);
    if ($parts === false || empty($parts['host'])) {
        log_error('POSTGRES_URL could not be parsed.');
        http_response_code(503);
        exit('The site is temporarily unavailable.');
    }

    // Vercel Postgres requires TLS. sslmode may already be in the query
    // string; default it to require when it is not.
    parse_str($parts['query'] ?? '', $query);
    $sslmode = $query['sslmode'] ?? 'require';

    $dsn = sprintf(
        'pgsql:host=%s;port=%d;dbname=%s;sslmode=%s',
        $parts['host'],
        $parts['port'] ?? 5432,
        ltrim($parts['path'] ?? '', '/'),
        $sslmode
    );

    try {
        $pdo = new PDO(
            $dsn,
            urldecode((string) ($parts['user'] ?? '')),
            urldecode((string) ($parts['pass'] ?? '')),
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_TIMEOUT            => 8,
            ]
        );
    } catch (PDOException $e) {
        // Never leak the connection string to the browser.
        log_error('Database connection failed: ' . $e->getMessage());
        http_response_code(503);
        exit('The site is temporarily unavailable. Please try again shortly.');
    }

    return $pdo;
}

/** Run a query with bound parameters and return the statement. */
function q(string $sql, array $params = []): PDOStatement
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/** First row, or null. */
function q_one(string $sql, array $params = []): ?array
{
    $row = q($sql, $params)->fetch();
    return $row === false ? null : $row;
}

/** All rows. */
function q_all(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

/** Single scalar value from the first column, or null. */
function q_val(string $sql, array $params = [])
{
    $val = q($sql, $params)->fetchColumn();
    return $val === false ? null : $val;
}

/**
 * INSERT and return the new id.
 * Postgres has no lastInsertId() without naming the sequence, so every
 * insert that needs its id uses RETURNING instead.
 */
function q_insert_id(string $sql, array $params = []): int
{
    return (int) q($sql . ' RETURNING id', $params)->fetchColumn();
}
