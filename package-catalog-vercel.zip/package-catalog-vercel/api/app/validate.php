<?php
/**
 * Small validator.
 *
 * Usage:
 *   $v = validate($_POST, [
 *       'name'  => 'required|max:140',
 *       'email' => 'nullable|email|max:190',
 *       'price' => 'required|numeric|min:0',
 *   ]);
 *   if ($v['errors']) { ... } else { $clean = $v['data']; }
 *
 * Rules: required, nullable, email, url, numeric, int, boolean,
 *        min:N, max:N, in:a,b,c, slug, phone
 */
declare(strict_types=1);

function validate(array $input, array $rules): array
{
    $data   = [];
    $errors = [];

    foreach ($rules as $field => $ruleString) {
        $raw   = $input[$field] ?? null;
        $value = is_string($raw) ? trim($raw) : $raw;
        $parts = explode('|', $ruleString);

        $nullable = in_array('nullable', $parts, true);
        $required = in_array('required', $parts, true);
        $isEmpty  = ($value === null || $value === '');

        if ($isEmpty) {
            if ($required) {
                $errors[$field] = t('v_required', ['field' => $field]);
                continue;
            }
            $data[$field] = $nullable ? null : '';
            continue;
        }

        foreach ($parts as $rule) {
            if ($rule === 'required' || $rule === 'nullable') {
                continue;
            }

            [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);

            switch ($name) {
                case 'email':
                    if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                        $errors[$field] = t('v_email');
                    }
                    break;

                case 'url':
                    if (!filter_var($value, FILTER_VALIDATE_URL)) {
                        $errors[$field] = t('v_url');
                    }
                    break;

                case 'numeric':
                    if (!is_numeric($value)) {
                        $errors[$field] = t('v_numeric');
                    } else {
                        $value = (float) $value;
                    }
                    break;

                case 'int':
                    if (filter_var($value, FILTER_VALIDATE_INT) === false) {
                        $errors[$field] = t('v_numeric');
                    } else {
                        $value = (int) $value;
                    }
                    break;

                case 'boolean':
                    $value = in_array($value, ['1', 1, true, 'on', 'true'], true) ? 1 : 0;
                    break;

                case 'min':
                    if (is_numeric($value)) {
                        if ((float) $value < (float) $arg) {
                            $errors[$field] = t('v_min_number', ['min' => $arg]);
                        }
                    } elseif (mb_strlen((string) $value) < (int) $arg) {
                        $errors[$field] = t('v_min_length', ['min' => $arg]);
                    }
                    break;

                case 'max':
                    if (is_numeric($value) && !is_string($value)) {
                        if ((float) $value > (float) $arg) {
                            $errors[$field] = t('v_max_number', ['max' => $arg]);
                        }
                    } elseif (mb_strlen((string) $value) > (int) $arg) {
                        $errors[$field] = t('v_max_length', ['max' => $arg]);
                    }
                    break;

                case 'in':
                    $allowed = explode(',', (string) $arg);
                    if (!in_array((string) $value, $allowed, true)) {
                        $errors[$field] = t('v_invalid');
                    }
                    break;

                case 'slug':
                    if (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', (string) $value)) {
                        $errors[$field] = t('v_slug');
                    }
                    break;

                case 'phone':
                    // Digits, spaces, +, -, ( ) — 7 to 20 characters.
                    if (!preg_match('/^[0-9+\-\s()]{7,20}$/', (string) $value)) {
                        $errors[$field] = t('v_phone');
                    }
                    break;
            }

            if (isset($errors[$field])) {
                break;
            }
        }

        if (!isset($errors[$field])) {
            $data[$field] = $value;
        }
    }

    return ['data' => $data, 'errors' => $errors];
}
