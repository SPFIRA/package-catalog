<?php
/**
 * Database session handler.
 *
 * PHP stores sessions as files by default. On Vercel each request may be
 * served by a different container with its own empty /tmp, so a file
 * session written on one request is invisible to the next: people would be
 * logged out at random and CSRF checks would reject valid forms.
 *
 * Keeping sessions in Postgres makes them shared and durable, which is what
 * the login and the CSRF token both depend on.
 */
declare(strict_types=1);

final class DatabaseSessionHandler implements SessionHandlerInterface
{
    public function open(string $path, string $name): bool
    {
        return true;
    }

    public function close(): bool
    {
        return true;
    }

    public function read(string $id): string
    {
        try {
            $row = q_one(
                'SELECT payload FROM sessions
                 WHERE id = ? AND last_active > NOW() - (? * INTERVAL \'1 second\')',
                [$id, SESSION_LIFETIME]
            );
        } catch (Throwable $e) {
            log_error('Session read failed: ' . $e->getMessage());
            return '';
        }
        return $row === null ? '' : (string) $row['payload'];
    }

    public function write(string $id, string $data): bool
    {
        try {
            q(
                'INSERT INTO sessions (id, payload, last_active)
                 VALUES (?, ?, NOW())
                 ON CONFLICT (id) DO UPDATE
                    SET payload = EXCLUDED.payload, last_active = NOW()',
                [$id, $data]
            );
        } catch (Throwable $e) {
            log_error('Session write failed: ' . $e->getMessage());
            return false;
        }
        return true;
    }

    public function destroy(string $id): bool
    {
        try {
            q('DELETE FROM sessions WHERE id = ?', [$id]);
        } catch (Throwable $e) {
            log_error('Session destroy failed: ' . $e->getMessage());
            return false;
        }
        return true;
    }

    /**
     * PHP calls this probabilistically. Sweeping here means no cron job is
     * needed, which matters because Vercel has no always-on process.
     */
    public function gc(int $maxLifetime): int|false
    {
        try {
            $stmt = q(
                'DELETE FROM sessions WHERE last_active < NOW() - (? * INTERVAL \'1 second\')',
                [max($maxLifetime, SESSION_LIFETIME)]
            );
            return $stmt->rowCount();
        } catch (Throwable $e) {
            log_error('Session gc failed: ' . $e->getMessage());
            return false;
        }
    }
}
