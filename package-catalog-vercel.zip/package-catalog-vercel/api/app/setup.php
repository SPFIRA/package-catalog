<?php
/**
 * One-time account creation, reachable at /setup?token=SETUP_TOKEN
 *
 * On shared hosting this was a standalone file you deleted afterwards.
 * There are no files to delete on Vercel — a deployment is immutable — so
 * the page is gated three ways instead:
 *
 *   1. SETUP_TOKEN must be set in the environment, or /setup is a 404.
 *   2. The supplied token must match it, compared with hash_equals.
 *   3. It refuses to run at all once any user exists.
 *
 * After creating your account, delete the SETUP_TOKEN variable in the
 * Vercel dashboard and redeploy. The route then returns 404 permanently.
 */
declare(strict_types=1);

function handle_setup(string $method): never
{
    // 1. no token configured -> the route does not exist
    if (SETUP_TOKEN === '') {
        show_error(404);
    }

    // 2. wrong token -> the route does not exist either, so probing it
    //    tells an attacker nothing
    $supplied = (string) ($_GET['token'] ?? $_POST['token'] ?? '');
    if (!hash_equals(SETUP_TOKEN, $supplied)) {
        show_error(404);
    }

    $errors = [];
    $done   = false;
    $users  = (int) q_val('SELECT COUNT(*) FROM users');

    // 3. already set up
    if ($users > 0) {
        http_response_code(410);
        $errors['_form'] = 'Setup is already complete. Delete the SETUP_TOKEN '
                         . 'environment variable in Vercel and redeploy.';
    } elseif ($method === 'POST') {
        csrf_check();

        $v = validate($_POST, [
            'name'     => 'required|max:120',
            'email'    => 'required|email|max:190',
            'password' => 'required|min:12|max:200',
        ]);

        $password = (string) ($_POST['password'] ?? '');
        $confirm  = (string) ($_POST['password_confirm'] ?? '');

        if ($password !== $confirm) {
            $v['errors']['password_confirm'] = 'The two passwords do not match.';
        }

        if ($v['errors']) {
            $errors = $v['errors'];
        } else {
            q(
                'INSERT INTO users (name, email, password_hash, role, is_active)
                 VALUES (?,?,?,?,1)',
                [
                    $v['data']['name'],
                    $v['data']['email'],
                    password_hash($password, PASSWORD_DEFAULT),
                    'admin',
                ]
            );
            $done = true;
        }
    }

    view('setup', [
        'errors' => $errors,
        'done'   => $done,
        'users'  => $users,
        'token'  => $supplied,
    ]);
    exit;
}
