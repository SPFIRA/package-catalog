<?php
/**
 * Admin authentication.
 */
declare(strict_types=1);

function auth_user(): ?array
{
    start_session();
    $id = $_SESSION['user_id'] ?? null;
    if (!$id) {
        return null;
    }

    static $user = null;
    if ($user === null) {
        $user = q_one(
            'SELECT id, name, email, role, is_active FROM users WHERE id = ? AND is_active = 1',
            [(int) $id]
        );
        if (!$user) {
            auth_logout();
            return null;
        }
    }
    return $user;
}

function auth_check(): bool
{
    return auth_user() !== null;
}

/** Redirect to login if not signed in. Call at the top of every admin route. */
function require_auth(): array
{
    $user = auth_user();
    if (!$user) {
        start_session();
        $_SESSION['intended'] = $_SERVER['REQUEST_URI'] ?? admin_url('');
        redirect(admin_url('login'));
    }
    return $user;
}

/**
 * Attempt a login.
 * Returns null on success, or a user-safe error string.
 * The message is deliberately identical for a wrong email and a wrong
 * password so it cannot be used to discover which accounts exist.
 */
function auth_attempt(string $email, string $password): ?string
{
    if (!rate_limit_ok('login', RATE_LOGIN[0], RATE_LOGIN[1])) {
        return t('login_throttled');
    }

    $user = q_one('SELECT * FROM users WHERE email = ? LIMIT 1', [$email]);

    // Always run a hash comparison so the response time does not reveal
    // whether the email exists.
    $hash = $user['password_hash'] ?? '$2y$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidinv';

    if (!password_verify($password, $hash) || !$user || (int) $user['is_active'] !== 1) {
        return t('login_failed');
    }

    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        q('UPDATE users SET password_hash = ? WHERE id = ?', [
            password_hash($password, PASSWORD_DEFAULT),
            $user['id'],
        ]);
    }

    start_session();
    session_regenerate_id(true);          // defeats session fixation
    $_SESSION['user_id']   = (int) $user['id'];
    $_SESSION['last_seen'] = time();

    q('UPDATE users SET last_login_at = NOW() WHERE id = ?', [$user['id']]);
    rate_limit_clear('login');

    return null;
}

function auth_logout(): void
{
    start_session();
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $p['path'],
            'domain'   => $p['domain'],
            'secure'   => $p['secure'],
            'httponly' => $p['httponly'],
            'samesite' => 'Lax',
        ]);
    }
    session_destroy();
}
