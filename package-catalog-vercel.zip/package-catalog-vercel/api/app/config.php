<?php
/**
 * Application configuration — Vercel deployment.
 *
 * There are no credentials in this file. Everything sensitive comes from
 * environment variables set in the Vercel dashboard
 * (Project -> Settings -> Environment Variables).
 *
 * Connecting a Vercel Postgres database creates POSTGRES_* automatically;
 * this file reads those, so the database needs no manual configuration.
 */
declare(strict_types=1);

/** Read an environment variable, with a fallback. */
function env(string $key, ?string $default = null): ?string
{
    $value = $_ENV[$key] ?? $_SERVER[$key] ?? getenv($key);
    if ($value === false || $value === null || $value === '') {
        return $default;
    }
    return (string) $value;
}

/**
 * Build the base URL from the request.
 * Vercel terminates TLS at the edge and forwards x-forwarded-proto.
 */
function request_base_url(): string
{
    $proto = $_SERVER['HTTP_X_FORWARDED_PROTO'] ?? (empty($_SERVER['HTTPS']) ? 'http' : 'https');
    $host  = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';

    // Reject anything that is not a plausible hostname, so a forged Host
    // header cannot rewrite every link on the page.
    if (!preg_match('/^[A-Za-z0-9.\-]+(:[0-9]+)?$/', (string) $host)) {
        $host = 'localhost';
    }
    return $proto . '://' . $host;
}

// ---------------------------------------------------------------
// Database — supplied by the Vercel Postgres integration
// ---------------------------------------------------------------
// Vercel sets POSTGRES_URL automatically when you attach a database.
// DATABASE_URL is accepted too, so the same code runs anywhere.
define('DATABASE_URL', env('POSTGRES_URL') ?? env('DATABASE_URL') ?? '');

// ---------------------------------------------------------------
// Site
// ---------------------------------------------------------------
// Leave APP_URL unset and the base URL is derived from the request, which
// keeps Vercel preview deployments working. Set it to your custom domain
// in production so redirects are stable.
define('APP_URL', rtrim((string) (env('APP_URL') ?? request_base_url()), '/'));

// Never enable on a public deployment.
define('APP_DEBUG', env('APP_DEBUG', '0') === '1');

// ---------------------------------------------------------------
// Admin
// ---------------------------------------------------------------
// Set ADMIN_PATH in Vercel to something only you know, e.g. 'sp-office'.
define('ADMIN_PATH', trim((string) env('ADMIN_PATH', 'manage'), '/'));

// Guards the one-time account creation page at /setup.
// Set SETUP_TOKEN in Vercel, visit /setup?token=THAT_VALUE to create your
// account, then delete the variable. Unset, /setup returns 404.
define('SETUP_TOKEN', (string) env('SETUP_TOKEN', ''));

define('SESSION_IDLE_TIMEOUT', 1800);   // 30 minutes
define('SESSION_LIFETIME', 86400);      // sessions older than this are swept

// ---------------------------------------------------------------
// Languages
// ---------------------------------------------------------------
define('LANGS', ['en' => 'English', 'am' => 'አማርኛ']);
define('DEFAULT_LANG', 'en');

// ---------------------------------------------------------------
// Rate limits — [max attempts, window in seconds]
// ---------------------------------------------------------------
define('RATE_LOGIN',   [5, 900]);    // 5 login attempts per 15 minutes
define('RATE_INQUIRY', [5, 3600]);   // 5 enquiries per hour per IP

// Minimum seconds a human needs to fill the enquiry form.
define('FORM_MIN_SECONDS', 3);

// Bump this after editing CSS or JS to bust the CDN cache. There is no
// filemtime() to rely on — assets are served by Vercel's CDN, not by PHP.
define('ASSET_VERSION', '1');
