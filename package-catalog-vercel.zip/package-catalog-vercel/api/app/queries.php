<?php
/**
 * Query layer. Every statement here is parameterised.
 * Column names are never interpolated from user input.
 */
declare(strict_types=1);

// ---------------------------------------------------------------
// Public reads
// ---------------------------------------------------------------

/** Published categories with a package count and a cheapest price. */
function public_categories(): array
{
    return q_all(
        'SELECT c.*,
                COUNT(p.id)  AS _count,
                MIN(p.price) AS _min_price
         FROM categories c
         LEFT JOIN packages p
                ON p.category_id = c.id
               AND p.is_active = 1
               AND p.deleted_at IS NULL
         WHERE c.is_active = 1
         GROUP BY c.id
         ORDER BY c.sort_order, c.name_en'
    );
}

function public_category(string $slug): ?array
{
    return q_one('SELECT * FROM categories WHERE slug = ? AND is_active = 1', [$slug]);
}

function public_packages(int $categoryId): array
{
    return q_all(
        'SELECT * FROM packages
         WHERE category_id = ? AND is_active = 1 AND deleted_at IS NULL
         ORDER BY sort_order, price',
        [$categoryId]
    );
}

function public_package(int $categoryId, string $slug): ?array
{
    return q_one(
        'SELECT * FROM packages
         WHERE category_id = ? AND slug = ? AND is_active = 1 AND deleted_at IS NULL',
        [$categoryId, $slug]
    );
}

function category_features(int $categoryId): array
{
    return q_all(
        'SELECT * FROM features WHERE category_id = ? ORDER BY sort_order, id',
        [$categoryId]
    );
}

/** Pivot rows keyed [package_id][feature_id] for the comparison table. */
function feature_matrix(array $packageIds): array
{
    if (!$packageIds) {
        return [];
    }
    $ids    = array_map('intval', $packageIds);
    $marks  = implode(',', array_fill(0, count($ids), '?'));
    $rows   = q_all("SELECT * FROM feature_package WHERE package_id IN ($marks)", $ids);
    $matrix = [];
    foreach ($rows as $row) {
        $matrix[(int) $row['package_id']][(int) $row['feature_id']] = $row;
    }
    return $matrix;
}

/** Features for one package, with pivot values merged in. */
function package_features(int $categoryId, int $packageId): array
{
    return q_all(
        'SELECT f.*, fp.is_included, fp.value_en, fp.value_am
         FROM features f
         LEFT JOIN feature_package fp
                ON fp.feature_id = f.id AND fp.package_id = ?
         WHERE f.category_id = ?
         ORDER BY f.sort_order, f.id',
        [$packageId, $categoryId]
    );
}

/** Add-ons for a category, plus the global ones. */
function public_addons(?int $categoryId): array
{
    if ($categoryId === null) {
        return q_all('SELECT * FROM addons WHERE is_active = 1 AND category_id IS NULL ORDER BY sort_order, id');
    }
    return q_all(
        'SELECT * FROM addons
         WHERE is_active = 1 AND (category_id = ? OR category_id IS NULL)
         ORDER BY category_id IS NULL, sort_order, id',
        [$categoryId]
    );
}

/** Categories with their packages, for the enquiry <select>. */
function grouped_packages(): array
{
    $categories = q_all(
        'SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name_en'
    );
    $out = [];
    foreach ($categories as $cat) {
        $packages = public_packages((int) $cat['id']);
        if ($packages) {
            $out[] = ['category' => $cat, 'packages' => $packages];
        }
    }
    return $out;
}

function count_public_packages(): int
{
    return (int) q_val(
        'SELECT COUNT(*) FROM packages p
         JOIN categories c ON c.id = p.category_id
         WHERE p.is_active = 1 AND p.deleted_at IS NULL AND c.is_active = 1'
    );
}

// ---------------------------------------------------------------
// Enquiries
// ---------------------------------------------------------------

/**
 * Freeze the package as quoted, so later price edits never rewrite
 * what this lead was actually shown.
 */
function build_snapshot(?array $package, ?array $category): ?string
{
    if (!$package) {
        return null;
    }
    $features = package_features((int) $package['category_id'], (int) $package['id']);
    $rows     = [];
    foreach ($features as $f) {
        $rows[] = [
            'label'    => $f['label_en'],
            'included' => (int) ($f['is_included'] ?? 0) === 1,
            'value'    => $f['value_en'],
        ];
    }

    return json_encode([
        'quoted_at'      => date('c'),
        'ref'            => $category ? package_ref($category, $package) : null,
        'category'       => $category['name_en'] ?? null,
        'package'        => $package['name_en'],
        'price'          => (float) $package['price'],
        'currency'       => $package['currency'],
        'delivery_days'  => $package['delivery_days'],
        'revision_rounds'=> $package['revision_rounds'],
        'support_months' => $package['support_months'],
        'features'       => $rows,
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function create_inquiry(array $data): int
{
    return q_insert_id(
        'INSERT INTO inquiries
           (package_id, package_snapshot, name, email, phone, company, message,
            source, lang, ip, user_agent)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        [
            $data['package_id'],
            $data['package_snapshot'],
            $data['name'],
            $data['email'],
            $data['phone'],
            $data['company'],
            $data['message'],
            $data['source'],
            $data['lang'],
            $data['ip'],
            $data['user_agent'],
        ]
    );
}

// ---------------------------------------------------------------
// Admin reads
// ---------------------------------------------------------------

function admin_categories(): array
{
    return q_all(
        'SELECT c.*, COUNT(p.id) AS _count
         FROM categories c
         LEFT JOIN packages p ON p.category_id = c.id AND p.deleted_at IS NULL
         GROUP BY c.id
         ORDER BY c.sort_order, c.name_en'
    );
}

function admin_category(int $id): ?array
{
    return q_one('SELECT * FROM categories WHERE id = ?', [$id]);
}

function admin_packages(?int $categoryId = null): array
{
    if ($categoryId) {
        return q_all(
            'SELECT p.*, c.name_en AS cat_en, c.name_am AS cat_am, c.slug AS cat_slug
             FROM packages p JOIN categories c ON c.id = p.category_id
             WHERE p.deleted_at IS NULL AND p.category_id = ?
             ORDER BY p.sort_order, p.price',
            [$categoryId]
        );
    }
    return q_all(
        'SELECT p.*, c.name_en AS cat_en, c.name_am AS cat_am, c.slug AS cat_slug
         FROM packages p JOIN categories c ON c.id = p.category_id
         WHERE p.deleted_at IS NULL
         ORDER BY c.sort_order, p.sort_order, p.price'
    );
}

function admin_package(int $id): ?array
{
    return q_one('SELECT * FROM packages WHERE id = ? AND deleted_at IS NULL', [$id]);
}

function admin_addons(): array
{
    return q_all(
        'SELECT a.*, c.name_en AS cat_en, c.name_am AS cat_am
         FROM addons a LEFT JOIN categories c ON c.id = a.category_id
         ORDER BY a.category_id IS NULL DESC, a.sort_order, a.id'
    );
}

function admin_addon(int $id): ?array
{
    return q_one('SELECT * FROM addons WHERE id = ?', [$id]);
}

function admin_inquiries(string $status = ''): array
{
    $allowed = ['new', 'contacted', 'quoted', 'won', 'lost'];
    if ($status !== '' && in_array($status, $allowed, true)) {
        return q_all(
            'SELECT i.*, p.name_en AS pkg_en, p.name_am AS pkg_am
             FROM inquiries i LEFT JOIN packages p ON p.id = i.package_id
             WHERE i.status = ? ORDER BY i.created_at DESC LIMIT 300',
            [$status]
        );
    }
    return q_all(
        'SELECT i.*, p.name_en AS pkg_en, p.name_am AS pkg_am
         FROM inquiries i LEFT JOIN packages p ON p.id = i.package_id
         ORDER BY i.created_at DESC LIMIT 300'
    );
}

function admin_inquiry(int $id): ?array
{
    return q_one(
        'SELECT i.*, p.name_en AS pkg_en, p.name_am AS pkg_am
         FROM inquiries i LEFT JOIN packages p ON p.id = i.package_id
         WHERE i.id = ?',
        [$id]
    );
}

function admin_stats(): array
{
    return [
        'new_inquiries' => (int) q_val("SELECT COUNT(*) FROM inquiries WHERE status = 'new'"),
        'packages'      => (int) q_val('SELECT COUNT(*) FROM packages WHERE is_active = 1 AND deleted_at IS NULL'),
        'categories'    => (int) q_val('SELECT COUNT(*) FROM categories WHERE is_active = 1'),
        'won_value'     => (float) (q_val(
            "SELECT COALESCE(SUM(p.price), 0) FROM inquiries i
             JOIN packages p ON p.id = i.package_id WHERE i.status = 'won'"
        ) ?? 0),
    ];
}

/** Ensure a slug is unique inside its scope, appending -2, -3 as needed. */
function unique_slug(string $table, string $slug, ?int $categoryId, int $ignoreId = 0): string
{
    $base = $slug;
    $n    = 1;

    while (true) {
        if ($table === 'packages') {
            $exists = q_val(
                'SELECT id FROM packages WHERE slug = ? AND category_id = ? AND id <> ?',
                [$slug, (int) $categoryId, $ignoreId]
            );
        } else {
            $exists = q_val('SELECT id FROM categories WHERE slug = ? AND id <> ?', [$slug, $ignoreId]);
        }
        if (!$exists) {
            return $slug;
        }
        $n++;
        $slug = $base . '-' . $n;
    }
}
