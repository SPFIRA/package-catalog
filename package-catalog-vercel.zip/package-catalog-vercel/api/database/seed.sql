-- ============================================================
--  Package Catalog — seed data (PostgreSQL)
--  Prices are placeholders. Edit them in the admin panel.
--  Run this AFTER schema.sql.
-- ============================================================

-- ============================================================
--  Package Catalog — seed data
--  Prices are placeholders. Edit them in the admin panel.
-- ============================================================

-- ---------- settings ----------
INSERT INTO settings ("key", value_en, value_am) VALUES
('site_name',    'Fira Studio', 'ፊራ ስቱዲዮ'),
('tagline',      'Software built for Ethiopian businesses', 'ለኢትዮጵያ ንግዶች የተሰራ ሶፍትዌር'),
('hero_line',    'Pick a package. Know the price before we start.', 'ጥቅል ይምረጡ። ከመጀመራችን በፊት ዋጋውን ይወቁ።'),
('hero_sub',     'Fixed scope, fixed price, fixed delivery date. No surprises halfway through.', 'የተወሰነ ስራ፣ የተወሰነ ዋጋ፣ የተወሰነ የማስረከቢያ ቀን። በመሃል ላይ ምንም አስገራሚ ነገር የለም።'),
('phone',        '+251 000 000 000', '+251 000 000 000'),
('email',        'fraolmarkos@gmail.com', 'fraolmarkos@gmail.com'),
('telegram',     'https://t.me/spfira', 'https://t.me/spfira'),
('footer_note',  'Based in Mizan-Tepi, working across Ethiopia.', 'በሚዛን-ተፒ ተመስርቶ በመላው ኢትዮጵያ ይሰራል።'),
('quote_validity','This pricing is held for 14 days from the date of enquiry.', 'ይህ ዋጋ ጥያቄ ከቀረበበት ቀን ጀምሮ ለ14 ቀናት ይቆያል።');

-- ---------- categories ----------
INSERT INTO categories (id,slug,name_en,name_am,tagline_en,tagline_am,description_en,description_am,icon,sort_order,is_active) VALUES
(1,'real-estate','Real Estate','ሪል እስቴት','Listings, leads and agents in one place.','ዝርዝሮች፣ ደንበኞች እና ወኪሎች በአንድ ቦታ።','For property companies selling or renting apartments, villas and commercial space. Publish listings without calling a developer, capture every enquiry, and stop losing buyers to a slow phone line.','አፓርታማ፣ ቪላ እና የንግድ ቦታ ለሚሸጡ ወይም ለሚያከራዩ የንብረት ኩባንያዎች። ገንቢ ሳይጠሩ ዝርዝሮችን ያውጡ፣ እያንዳንዱን ጥያቄ ይያዙ።','building',1,1),
(2,'hotel-restaurant','Hotel & Restaurant','ሆቴል እና ሬስቶራንት','Rooms, orders and the kitchen, connected.','ክፍሎች፣ ትዕዛዞች እና ወጥ ቤት፣ የተገናኙ።','For hotels, lodges and full-service restaurants. Take bookings online, run the floor from a tablet, and see the day''s revenue without counting slips.','ለሆቴሎች፣ ማረፊያዎች እና ሙሉ አገልግሎት ሬስቶራንቶች። በመስመር ላይ ቦታ ያስያዙ፣ የቀኑን ገቢ ወዲያውኑ ይመልከቱ።','bed',2,1),
(3,'health','Health','ጤና','Patients, appointments and records.','ታካሚዎች፣ ቀጠሮዎች እና መዝገቦች።','For clinics, pharmacies and diagnostic labs. Book patients, keep a searchable history, and print results the same day.','ለክሊኒኮች፣ ፋርማሲዎች እና የምርመራ ላቦራቶሪዎች። ታካሚዎችን ይመዝግቡ፣ ውጤቶችን በዚያው ቀን ያትሙ።','pulse',3,1),
(4,'cafe','Cafe & Retail','ካፌ እና ችርቻሮ','A menu people can actually find.','ሰዎች በእርግጥ ሊያገኙት የሚችሉት ምናሌ።','For cafes, bakeries and small shops. A menu that loads fast on a phone, orders that reach the counter, and stock you can trust.','ለካፌዎች፣ ዳቦ ቤቶች እና ትናንሽ ሱቆች። በስልክ በፍጥነት የሚጫን ምናሌ እና የሚያምኑበት ክምችት።','cup',4,1);

-- ============================================================
--  1. REAL ESTATE
-- ============================================================
INSERT INTO features (id,category_id,label_en,label_am,sort_order) VALUES
(101,1,'Company website (Home, About, Services, Contact)','የኩባንያ ድረ-ገጽ (መነሻ፣ ስለ እኛ፣ አገልግሎቶች፣ አድራሻ)',1),
(102,1,'Property listings with photos','ንብረቶች ከፎቶ ጋር',2),
(103,1,'Admin dashboard — add, edit, remove listings','የአስተዳደር ዳሽቦርድ — መጨመር፣ ማረም፣ ማስወገድ',3),
(104,1,'Search and filters (price, location, bedrooms)','ፍለጋ እና ማጣሪያ (ዋጋ፣ ቦታ፣ መኝታ ክፍል)',4),
(105,1,'Enquiry capture and lead tracking','የደንበኛ ጥያቄ መያዝ እና መከታተል',5),
(106,1,'Agent accounts with their own listings','የወኪል መለያዎች ከየራሳቸው ዝርዝር ጋር',6),
(107,1,'Amharic and English','አማርኛ እና እንግሊዝኛ',7),
(108,1,'Payment and instalment tracking','የክፍያ እና የዕዳ ክፍያ መከታተያ',8),
(109,1,'Reports and analytics','ሪፖርቶች እና ትንተና',9),
(110,1,'Training sessions','የስልጠና ክፍለ ጊዜዎች',10),
(111,1,'Free support after launch','ከተጀመረ በኋላ ነጻ ድጋፍ',11);

INSERT INTO packages (id,category_id,slug,name_en,name_am,tagline_en,tagline_am,summary_en,summary_am,price,price_note_en,price_note_am,delivery_days,revision_rounds,support_months,is_featured,sort_order) VALUES
(1001,1,'starter','Starter','መነሻ','A credible presence, fast.','ታማኝ መገኘት፣ በፍጥነት።','A clean four-page site with up to 20 properties. You send me the listings, I publish them.','እስከ 20 ንብረቶች ያሉት ንጹህ የአራት ገጽ ድረ-ገጽ። ዝርዝሮቹን ይላኩልኝ፣ እኔ አወጣቸዋለሁ።',30000,'one-time','አንድ ጊዜ',14,2,1,0,1),
(1002,1,'professional','Professional','ፕሮፌሽናል','You control the listings.','ዝርዝሮቹን እርስዎ ይቆጣጠራሉ።','Everything in Starter, plus an admin panel so you add and edit properties yourself, in Amharic or English, with every enquiry tracked.','በመነሻ ውስጥ ያለው ሁሉ፣ በተጨማሪም ንብረቶችን በራስዎ የሚጨምሩበት የአስተዳደር ክፍል።',75000,'one-time','አንድ ጊዜ',35,3,3,1,2),
(1003,1,'enterprise','Enterprise','ኢንተርፕራይዝ','Run the whole agency.','ሙሉ ኤጀንሲውን ያንቀሳቅሱ።','Multi-agent accounts, map search, instalment tracking and full reporting. Built for an agency with staff, not a single owner.','የበርካታ ወኪል መለያዎች፣ የካርታ ፍለጋ፣ የክፍያ መከታተያ እና ሙሉ ሪፖርት።',160000,'one-time','አንድ ጊዜ',70,4,6,0,3);

INSERT INTO feature_package (package_id,feature_id,is_included,value_en,value_am) VALUES
(1001,101,1,NULL,NULL),(1001,102,1,'Up to 20, I publish them','እስከ 20፣ እኔ አወጣቸዋለሁ'),(1001,103,0,NULL,NULL),
(1001,104,0,NULL,NULL),(1001,105,1,'Email form','የኢሜይል ቅጽ'),(1001,106,0,NULL,NULL),
(1001,107,0,'English only','እንግሊዝኛ ብቻ'),(1001,108,0,NULL,NULL),(1001,109,0,NULL,NULL),
(1001,110,1,'1 session','1 ክፍለ ጊዜ'),(1001,111,1,'1 month','1 ወር'),

(1002,101,1,NULL,NULL),(1002,102,1,'Unlimited, you manage','ያልተገደበ፣ እርስዎ ያስተዳድራሉ'),(1002,103,1,NULL,NULL),
(1002,104,1,NULL,NULL),(1002,105,1,'Lead inbox with status','የደንበኛ ሳጥን ከሁኔታ ጋር'),(1002,106,0,NULL,NULL),
(1002,107,1,NULL,NULL),(1002,108,0,NULL,NULL),(1002,109,1,'Basic','መሰረታዊ'),
(1002,110,1,'2 sessions','2 ክፍለ ጊዜዎች'),(1002,111,1,'3 months','3 ወራት'),

(1003,101,1,NULL,NULL),(1003,102,1,'Unlimited + video and 360°','ያልተገደበ + ቪዲዮ እና 360°'),(1003,103,1,'With roles and permissions','ከሚና እና ፈቃድ ጋር'),
(1003,104,1,'Advanced + map view','የላቀ + የካርታ እይታ'),(1003,105,1,'Full CRM with reminders','ሙሉ CRM ከማስታወሻ ጋር'),(1003,106,1,NULL,NULL),
(1003,107,1,NULL,NULL),(1003,108,1,NULL,NULL),(1003,109,1,'Full analytics','ሙሉ ትንተና'),
(1003,110,1,'3 sessions + manual','3 ክፍለ ጊዜዎች + መመሪያ'),(1003,111,1,'6 months','6 ወራት');

-- ============================================================
--  2. HOTEL & RESTAURANT
-- ============================================================
INSERT INTO features (id,category_id,label_en,label_am,sort_order) VALUES
(201,2,'Website with rooms and menu','ድረ-ገጽ ከክፍሎች እና ምናሌ ጋር',1),
(202,2,'Online room booking','የመስመር ላይ ክፍል ማስያዝ',2),
(203,2,'Table and order management','የጠረጴዛ እና ትዕዛዝ አስተዳደር',3),
(204,2,'Kitchen display / order routing','የወጥ ቤት ማሳያ / ትዕዛዝ ማስተላለፍ',4),
(205,2,'Stock and inventory','ክምችት እና ዕቃ ቆጠራ',5),
(206,2,'Daily revenue reports','የዕለት ገቢ ሪፖርቶች',6),
(207,2,'Staff accounts and shifts','የሰራተኛ መለያ እና ፈረቃ',7),
(208,2,'Amharic and English','አማርኛ እና እንግሊዝኛ',8),
(209,2,'Free support after launch','ከተጀመረ በኋላ ነጻ ድጋፍ',9);

INSERT INTO packages (id,category_id,slug,name_en,name_am,tagline_en,tagline_am,summary_en,summary_am,price,price_note_en,price_note_am,delivery_days,revision_rounds,support_months,is_featured,sort_order) VALUES
(2001,2,'starter','Starter','መነሻ','Be findable.','እንዲገኙ ያድርጉ።','A fast website with your rooms, menu and photos, and a booking request form.','ክፍሎችዎን፣ ምናሌዎን እና ፎቶዎችን የያዘ ፈጣን ድረ-ገጽ።',28000,'one-time','አንድ ጊዜ',14,2,1,0,1),
(2002,2,'professional','Professional','ፕሮፌሽናል','Run the floor.','ወለሉን ያንቀሳቅሱ።','Online booking plus table and order management, with daily revenue you can read at closing.','የመስመር ላይ ማስያዝ ከጠረጴዛ እና ትዕዛዝ አስተዳደር ጋር።',85000,'one-time','አንድ ጊዜ',40,3,3,1,2),
(2003,2,'enterprise','Enterprise','ኢንተርፕራይዝ','Hotel and kitchen as one system.','ሆቴል እና ወጥ ቤት እንደ አንድ ስርዓት።','Full property management: bookings, POS, kitchen routing, stock, staff shifts and reporting.','ሙሉ የንብረት አስተዳደር፦ ማስያዝ፣ POS፣ ወጥ ቤት፣ ክምችት እና ሪፖርት።',180000,'one-time','አንድ ጊዜ',75,4,6,0,3);

INSERT INTO feature_package (package_id,feature_id,is_included,value_en,value_am) VALUES
(2001,201,1,NULL,NULL),(2001,202,1,'Request form only','የጥያቄ ቅጽ ብቻ'),(2001,203,0,NULL,NULL),(2001,204,0,NULL,NULL),
(2001,205,0,NULL,NULL),(2001,206,0,NULL,NULL),(2001,207,0,NULL,NULL),(2001,208,0,'English only','እንግሊዝኛ ብቻ'),(2001,209,1,'1 month','1 ወር'),
(2002,201,1,NULL,NULL),(2002,202,1,'Live availability','በቀጥታ ያለው ሁኔታ'),(2002,203,1,NULL,NULL),(2002,204,1,NULL,NULL),
(2002,205,1,'Basic','መሰረታዊ'),(2002,206,1,NULL,NULL),(2002,207,0,NULL,NULL),(2002,208,1,NULL,NULL),(2002,209,1,'3 months','3 ወራት'),
(2003,201,1,NULL,NULL),(2003,202,1,'Live + deposits','በቀጥታ + ቅድሚያ ክፍያ'),(2003,203,1,NULL,NULL),(2003,204,1,NULL,NULL),
(2003,205,1,'Full with alerts','ሙሉ ከማንቂያ ጋር'),(2003,206,1,'Full analytics','ሙሉ ትንተና'),(2003,207,1,NULL,NULL),(2003,208,1,NULL,NULL),(2003,209,1,'6 months','6 ወራት');

-- ============================================================
--  3. HEALTH
-- ============================================================
INSERT INTO features (id,category_id,label_en,label_am,sort_order) VALUES
(301,3,'Clinic website with services and hours','የክሊኒክ ድረ-ገጽ ከአገልግሎት እና ሰዓት ጋር',1),
(302,3,'Appointment booking','ቀጠሮ ማስያዝ',2),
(303,3,'Patient records, searchable','የታካሚ መዝገብ፣ የሚፈለግ',3),
(304,3,'Lab result entry and printing','የላብ ውጤት ማስገባት እና ማተም',4),
(305,3,'Pharmacy stock','የፋርማሲ ክምችት',5),
(306,3,'Billing and receipts','ክፍያ እና ደረሰኝ',6),
(307,3,'Staff roles and permissions','የሰራተኛ ሚና እና ፈቃድ',7),
(308,3,'Amharic and English','አማርኛ እና እንግሊዝኛ',8),
(309,3,'Free support after launch','ከተጀመረ በኋላ ነጻ ድጋፍ',9);

INSERT INTO packages (id,category_id,slug,name_en,name_am,tagline_en,tagline_am,summary_en,summary_am,price,price_note_en,price_note_am,delivery_days,revision_rounds,support_months,is_featured,sort_order) VALUES
(3001,3,'starter','Starter','መነሻ','Patients can find you and book.','ታካሚዎች ሊያገኙዎት እና ሊመዘገቡ ይችላሉ።','A clear website with services, hours, location and an appointment request form.','አገልግሎቶች፣ ሰዓታት፣ ቦታ እና የቀጠሮ ጥያቄ ቅጽ ያለው ግልጽ ድረ-ገጽ።',32000,'one-time','አንድ ጊዜ',14,2,1,0,1),
(3002,3,'professional','Professional','ፕሮፌሽናል','Records that do not go missing.','የማይጠፉ መዝገቦች።','Appointments plus searchable patient records, billing and receipts, with roles for reception and clinicians.','ቀጠሮዎች ከሚፈለጉ የታካሚ መዝገቦች፣ ክፍያ እና ደረሰኝ ጋር።',95000,'one-time','አንድ ጊዜ',45,3,3,1,2),
(3003,3,'enterprise','Enterprise','ኢንተርፕራይዝ','Clinic, lab and pharmacy together.','ክሊኒክ፣ ላብ እና ፋርማሲ በአንድ ላይ።','Adds lab result workflow and pharmacy stock, with full permissions and reporting across departments.','የላብ ውጤት ሂደት እና የፋርማሲ ክምችት ይጨምራል።',200000,'one-time','አንድ ጊዜ',80,4,6,0,3);

INSERT INTO feature_package (package_id,feature_id,is_included,value_en,value_am) VALUES
(3001,301,1,NULL,NULL),(3001,302,1,'Request form','የጥያቄ ቅጽ'),(3001,303,0,NULL,NULL),(3001,304,0,NULL,NULL),
(3001,305,0,NULL,NULL),(3001,306,0,NULL,NULL),(3001,307,0,NULL,NULL),(3001,308,0,'English only','እንግሊዝኛ ብቻ'),(3001,309,1,'1 month','1 ወር'),
(3002,301,1,NULL,NULL),(3002,302,1,'Calendar with slots','የቀን መቁጠሪያ ከክፍተት ጋር'),(3002,303,1,NULL,NULL),(3002,304,0,NULL,NULL),
(3002,305,0,NULL,NULL),(3002,306,1,NULL,NULL),(3002,307,1,'2 roles','2 ሚናዎች'),(3002,308,1,NULL,NULL),(3002,309,1,'3 months','3 ወራት'),
(3003,301,1,NULL,NULL),(3003,302,1,'Calendar + reminders','የቀን መቁጠሪያ + ማስታወሻ'),(3003,303,1,NULL,NULL),(3003,304,1,NULL,NULL),
(3003,305,1,NULL,NULL),(3003,306,1,'With reports','ከሪፖርት ጋር'),(3003,307,1,'Unlimited roles','ያልተገደበ ሚና'),(3003,308,1,NULL,NULL),(3003,309,1,'6 months','6 ወራት');

-- ============================================================
--  4. CAFE & RETAIL
-- ============================================================
INSERT INTO features (id,category_id,label_en,label_am,sort_order) VALUES
(401,4,'One-page site with menu and location','የአንድ ገጽ ድረ-ገጽ ከምናሌ እና ቦታ ጋር',1),
(402,4,'Menu you edit yourself','በራስዎ የሚያርሙት ምናሌ',2),
(403,4,'QR code menu for tables','ለጠረጴዛዎች የQR ኮድ ምናሌ',3),
(404,4,'Online orders','የመስመር ላይ ትዕዛዞች',4),
(405,4,'Sales and stock tracking','የሽያጭ እና ክምችት መከታተያ',5),
(406,4,'Amharic and English','አማርኛ እና እንግሊዝኛ',6),
(407,4,'Free support after launch','ከተጀመረ በኋላ ነጻ ድጋፍ',7);

INSERT INTO packages (id,category_id,slug,name_en,name_am,tagline_en,tagline_am,summary_en,summary_am,price,price_note_en,price_note_am,delivery_days,revision_rounds,support_months,is_featured,sort_order) VALUES
(4001,4,'starter','Starter','መነሻ','Your menu, on a phone, in two seconds.','ምናሌዎ በስልክ ላይ በሁለት ሰከንድ።','A single fast page with your menu, photos, hours and directions.','ምናሌዎን፣ ፎቶዎችን፣ ሰዓታትን እና አቅጣጫን የያዘ አንድ ፈጣን ገጽ።',15000,'one-time','አንድ ጊዜ',7,2,1,0,1),
(4002,4,'professional','Professional','ፕሮፌሽናል','Change the price without calling me.','እኔን ሳይደውሉ ዋጋ ይቀይሩ።','Adds an admin panel and QR table menus, so prices and items are yours to change any morning.','የአስተዳደር ክፍል እና የQR ጠረጴዛ ምናሌ ይጨምራል።',45000,'one-time','አንድ ጊዜ',21,3,3,1,2),
(4003,4,'enterprise','Enterprise','ኢንተርፕራይዝ','Orders and stock, counted.','ትዕዛዞች እና ክምችት፣ የተቆጠሩ።','Online ordering with sales and stock tracking, so the till and the storeroom agree.','የመስመር ላይ ትዕዛዝ ከሽያጭ እና ክምችት መከታተያ ጋር።',110000,'one-time','አንድ ጊዜ',50,4,6,0,3);

INSERT INTO feature_package (package_id,feature_id,is_included,value_en,value_am) VALUES
(4001,401,1,NULL,NULL),(4001,402,0,NULL,NULL),(4001,403,0,NULL,NULL),(4001,404,0,NULL,NULL),
(4001,405,0,NULL,NULL),(4001,406,0,'English only','እንግሊዝኛ ብቻ'),(4001,407,1,'1 month','1 ወር'),
(4002,401,1,NULL,NULL),(4002,402,1,NULL,NULL),(4002,403,1,NULL,NULL),(4002,404,0,NULL,NULL),
(4002,405,0,NULL,NULL),(4002,406,1,NULL,NULL),(4002,407,1,'3 months','3 ወራት'),
(4003,401,1,NULL,NULL),(4003,402,1,NULL,NULL),(4003,403,1,NULL,NULL),(4003,404,1,NULL,NULL),
(4003,405,1,NULL,NULL),(4003,406,1,NULL,NULL),(4003,407,1,'6 months','6 ወራት');

-- ---------- add-ons (category_id NULL = applies everywhere) ----------
INSERT INTO addons (category_id,name_en,name_am,description_en,description_am,price,billing_cycle,sort_order) VALUES
(NULL,'Hosting and maintenance','ማስተናገጃ እና ጥገና','I keep the site online, backed up and updated. Domain and hosting fees are paid by you, in your name.','ድረ-ገጹን በመስመር ላይ፣ ተጠባባቂ እና የተዘመነ አድርጌ እይዛለሁ።',3500,'monthly',1),
(NULL,'Extra revision round','ተጨማሪ የማረሚያ ዙር','One more round of changes beyond what your package includes.','ከጥቅልዎ በላይ አንድ ተጨማሪ የለውጥ ዙር።',4000,'one_time',2),
(NULL,'On-site training day','የቦታ ላይ ስልጠና ቀን','A full day at your office training your staff. Travel outside Mizan-Tepi billed separately.','በቢሮዎ ውስጥ ሰራተኞችዎን የማሰልጠን ሙሉ ቀን።',5000,'one_time',3),
(NULL,'Content entry','የይዘት ማስገባት','I enter your first 50 items, listings or products so you start with a full site.','የመጀመሪያዎቹን 50 እቃዎች ወይም ዝርዝሮች እኔ አስገባለሁ።',6000,'one_time',4),
(1,'Property photography','የንብረት ፎቶግራፍ','Photos of up to 5 properties, edited and sized for the web.','እስከ 5 ንብረቶች ፎቶዎች፣ ተስተካክለው ለድረ-ገጽ የተመጣጠኑ።',8000,'one_time',5);

-- ------------------------------------------------------------
-- Explicit ids were inserted above, so move each identity sequence
-- past them. Without this the first row you add in the admin panel
-- would collide with an existing id.
-- ------------------------------------------------------------
SELECT setval(pg_get_serial_sequence('categories','id'), COALESCE((SELECT MAX(id) FROM categories), 1));
SELECT setval(pg_get_serial_sequence('packages','id'),   COALESCE((SELECT MAX(id) FROM packages), 1));
SELECT setval(pg_get_serial_sequence('features','id'),   COALESCE((SELECT MAX(id) FROM features), 1));
SELECT setval(pg_get_serial_sequence('addons','id'),     COALESCE((SELECT MAX(id) FROM addons), 1));
