<?php
/**
 * Front controller. Every request enters here.
 */
declare(strict_types=1);

require __DIR__ . '/app/config.php';
require __DIR__ . '/app/helpers.php';
require __DIR__ . '/app/db.php';
require __DIR__ . '/app/session.php';
require __DIR__ . '/app/security.php';
require __DIR__ . '/app/validate.php';
require __DIR__ . '/app/auth.php';
require __DIR__ . '/app/queries.php';

// ---------------------------------------------------------------
// Error handling — log everything, show nothing sensitive
// ---------------------------------------------------------------
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ini_set('log_errors', '1');
ini_set('session.gc_maxlifetime', (string) SESSION_LIFETIME);
error_reporting(E_ALL);
date_default_timezone_set('Africa/Addis_Ababa');

set_exception_handler(function (Throwable $ex): void {
    log_error(sprintf(
        "%s: %s in %s:%d\n%s",
        get_class($ex), $ex->getMessage(), $ex->getFile(), $ex->getLine(), $ex->getTraceAsString()
    ));
    if (APP_DEBUG) {
        http_response_code(500);
        echo '<pre>' . htmlspecialchars((string) $ex, ENT_QUOTES) . '</pre>';
        return;
    }
    show_error(500);
});

set_error_handler(function (int $no, string $str, string $file, int $line): bool {
    if (!(error_reporting() & $no)) {
        return false;
    }
    throw new ErrorException($str, 0, $no, $file, $line);
});

function show_error(int $code): never
{
    http_response_code($code);
    view('error', ['code' => $code]);
    exit;
}

send_security_headers();
start_session();

// ---------------------------------------------------------------
// Routing
// ---------------------------------------------------------------
$uri  = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
$base = rtrim((string) parse_url(APP_URL, PHP_URL_PATH), '/');

if ($base !== '' && str_starts_with($uri, $base)) {
    $uri = substr($uri, strlen($base));
}

$path     = trim(rawurldecode($uri), '/');
$segments = $path === '' ? [] : explode('/', $path);
$method   = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

// Admin is mounted under a configurable prefix.
if (($segments[0] ?? '') === ADMIN_PATH) {
    array_shift($segments);
    require __DIR__ . '/app/admin.php';
    admin_route($segments, $method);
    exit;
}

switch ($segments[0] ?? '') {

    // ---------------- home ----------------
    case '':
        view('home', [
            'categories'    => public_categories(),
            'totalPackages' => count_public_packages(),
            'grouped'       => grouped_packages(),
            'errors'        => errors_take(),
        ]);
        break;

    // ---------------- category ----------------
    case 'c':
        $category = public_category($segments[1] ?? '');
        if (!$category) {
            show_error(404);
        }
        $packages = public_packages((int) $category['id']);
        view('category', [
            'category' => $category,
            'packages' => $packages,
            'features' => category_features((int) $category['id']),
            'matrix'   => feature_matrix(array_column($packages, 'id')),
            'addons'   => public_addons((int) $category['id']),
            'grouped'  => grouped_packages(),
            'errors'   => errors_take(),
        ]);
        break;

    // ---------------- single package ----------------
    case 'p':
        $category = public_category($segments[1] ?? '');
        if (!$category) {
            show_error(404);
        }
        $package = public_package((int) $category['id'], $segments[2] ?? '');
        if (!$package) {
            show_error(404);
        }
        view('package', [
            'category' => $category,
            'package'  => $package,
            'features' => package_features((int) $category['id'], (int) $package['id']),
            'addons'   => public_addons((int) $category['id']),
            'grouped'  => grouped_packages(),
            'errors'   => errors_take(),
        ]);
        break;

    // ---------------- enquiry submission ----------------
    case 'enquiry':
        if ($method !== 'POST') {
            redirect(url('/'));
        }
        handle_enquiry();
        break;

    case 'thanks':
        view('thanks');
        break;

    // ---------------- one-time account creation ----------------
    // Guarded by SETUP_TOKEN so the page cannot be found by scanning.
    case 'setup':
        require __DIR__ . '/app/setup.php';
        handle_setup($method);
        break;

    default:
        show_error(404);
}

/**
 * Validate and store an enquiry.
 *
 * Three layers stop automated submissions before the database is touched:
 * a CSRF token, a honeypot field no human sees, and a minimum fill time.
 * The rate limit then caps how often any one address can submit.
 */
function handle_enquiry(): never
{
    csrf_check();

    $back = $_SERVER['HTTP_REFERER'] ?? url('/');
    $back = str_starts_with($back, rtrim(APP_URL, '/')) ? $back : url('/');

    // Honeypot: a real browser leaves this empty because it is off-screen.
    if (trim((string) ($_POST['website_url'] ?? '')) !== '') {
        redirect(url('/thanks'));   // silent success, so bots learn nothing
    }

    // Timing: a human cannot read and complete this form in under 3 seconds.
    $started = (int) ($_POST['_started'] ?? 0);
    if ($started <= 0 || (time() - $started) < FORM_MIN_SECONDS) {
        redirect(url('/thanks'));
    }

    if (!rate_limit_ok('inquiry', RATE_INQUIRY[0], RATE_INQUIRY[1])) {
        remember_input($_POST);
        remember_errors(['_form' => t('enquiry_throttled')]);
        redirect($back . '#enquiry');
    }

    $v = validate($_POST, [
        'name'       => 'required|max:140',
        'phone'      => 'required|phone|max:40',
        'email'      => 'nullable|email|max:190',
        'company'    => 'nullable|max:160',
        'message'    => 'nullable|max:4000',
        'package_id' => 'nullable|int',
    ]);

    if ($v['errors']) {
        remember_input($_POST);
        remember_errors($v['errors'] + ['_form' => t('enquiry_failed')]);
        redirect($back . '#enquiry');
    }

    $data      = $v['data'];
    $packageId = !empty($data['package_id']) ? (int) $data['package_id'] : null;
    $package   = null;
    $category  = null;

    if ($packageId) {
        $package = q_one(
            'SELECT * FROM packages WHERE id = ? AND is_active = 1 AND deleted_at IS NULL',
            [$packageId]
        );
        if (!$package) {
            $packageId = null;                       // stale or tampered id
        } else {
            $category = admin_category((int) $package['category_id']);
        }
    }

    create_inquiry([
        'package_id'       => $packageId,
        'package_snapshot' => build_snapshot($package, $category),
        'name'             => $data['name'],
        'email'            => $data['email'] ?: null,
        'phone'            => $data['phone'],
        'company'          => $data['company'] ?: null,
        'message'          => $data['message'] ?: null,
        'source'           => substr((string) ($_SERVER['HTTP_REFERER'] ?? 'direct'), 0, 60),
        'lang'             => current_lang(),
        'ip'               => client_ip(),
        'user_agent'       => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
    ]);

    clear_old();
    redirect(url('/thanks'));
}
