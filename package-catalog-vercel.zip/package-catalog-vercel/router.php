<?php
/**
 * Local preview only — mimics Vercel's routing so you can run the site with
 * PHP's built-in server:
 *
 *   php -S 127.0.0.1:8000 -t . router.php
 *
 * Vercel itself uses vercel.json and never loads this file.
 */
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// static assets are served straight from disk, as the CDN would
if (preg_match('#^/assets/#', $path) && is_file(__DIR__ . $path)) {
    return false;
}

$_SERVER['SCRIPT_NAME'] = '/api/index.php';
require __DIR__ . '/api/index.php';
